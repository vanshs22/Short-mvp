"""Health + metrics smoke tests."""
from fastapi.testclient import TestClient


def test_health(client: TestClient):
    r = client.get("/api/health")
    assert r.status_code == 200
    data = r.json()
    assert data["status"] == "ok"
    assert "version" in data
    assert "available_templates" in data
    assert "standard" in data["available_templates"]


def test_root(client: TestClient):
    r = client.get("/")
    assert r.status_code == 200


def test_metrics(client: TestClient, auth_headers):
    r = client.get("/api/metrics", headers=auth_headers)
    assert r.status_code == 200

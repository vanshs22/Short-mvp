"""Deep security tests: access control, SSRF, path traversal, headers, credits."""
from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from app.services.security import assert_safe_external_url, escape_ffmpeg_path, assert_job_access
from app.services.upload_security import safe_output_path
from app.models.schemas import JobResponse, UserResponse, JobStatus
from datetime import datetime
from fastapi import HTTPException


def test_ssrf_blocks_localhost():
    with pytest.raises(HTTPException):
        assert_safe_external_url("http://127.0.0.1/secret")
    with pytest.raises(HTTPException):
        assert_safe_external_url("http://localhost/admin")
    with pytest.raises(HTTPException):
        assert_safe_external_url("http://169.254.169.254/latest/meta-data/")
    with pytest.raises(HTTPException):
        assert_safe_external_url("file:///etc/passwd")


def test_ssrf_blocks_private_ip():
    with pytest.raises(HTTPException):
        assert_safe_external_url("http://192.168.1.1/")
    with pytest.raises(HTTPException):
        assert_safe_external_url("http://10.0.0.5/")


def test_ssrf_allows_youtube():
    url = assert_safe_external_url(
        "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
        allow_hosts=("youtube.com", "www.youtube.com", "youtu.be"),
    )
    assert "youtube.com" in url


def test_ffmpeg_escape():
    s = escape_ffmpeg_path(r"C:\path:with'quote,[x]")
    assert "'" not in s or r"\'" in s
    assert ":\\" in s or "\\:" in s or "C" in s


def test_job_access_private(client: TestClient, registered_user, auth_headers):
    user, token, email, password = registered_user
    # Create a job owned by user via service
    from app.services.pipeline import create_job
    from app.models.schemas import CreateJobRequest
    job = create_job(CreateJobRequest(script="security test script for access control."), user_id=user["id"])
    # Unauthenticated cannot read private job
    r = client.get(f"/api/jobs/{job.id}")
    assert r.status_code in (401, 403)
    # Owner can
    r2 = client.get(f"/api/jobs/{job.id}", headers=auth_headers)
    assert r2.status_code == 200


def test_list_jobs_anonymous_empty(client: TestClient):
    r = client.get("/api/jobs")
    assert r.status_code == 200
    assert r.json() == []


def test_metrics_requires_auth(client: TestClient):
    r = client.get("/api/metrics")
    assert r.status_code == 401


def test_path_traversal_outputs(client: TestClient):
    r = client.get("/api/outputs/../../etc/passwd")
    assert r.status_code in (400, 404)


def test_background_upload_requires_auth(client: TestClient):
    r = client.post(
        "/api/backgrounds",
        files={"file": ("x.mp4", b"\x00\x00\x00\x18ftypmp42" + b"\x00" * 64, "video/mp4")},
    )
    assert r.status_code == 401


def test_assert_job_access_helper():
    owner = UserResponse(
        id="u1", email="a@b.com", name=None, plan="free",
        credits_remaining=10, videos_this_week=0, created_at=datetime.utcnow(),
    )
    other = UserResponse(
        id="u2", email="c@d.com", name=None, plan="free",
        credits_remaining=10, videos_this_week=0, created_at=datetime.utcnow(),
    )
    job = JobResponse(
        id="j1", status=JobStatus.PENDING, progress=0, message="",
        created_at=datetime.utcnow(), updated_at=datetime.utcnow(),
        user_id="u1",
    )
    assert_job_access(job, owner)
    with pytest.raises(HTTPException):
        assert_job_access(job, other)
    with pytest.raises(HTTPException):
        assert_job_access(job, None)

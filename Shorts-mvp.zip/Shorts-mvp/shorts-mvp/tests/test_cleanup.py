"""Cleanup service smoke test."""
from app.services.cleanup import cleanup_old_outputs


def test_cleanup_runs():
    stats = cleanup_old_outputs(retention_days=0)  # aggressive in test env
    assert "deleted_files" in stats
    assert "expired_tokens" in stats
    assert stats["retention_days"] == 0

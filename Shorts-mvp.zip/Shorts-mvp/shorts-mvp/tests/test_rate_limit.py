"""Rate limit – confirm limiter module is importable and decorator is applied."""
from app.api import routes as routes_mod
from app.core.config import settings


def test_rate_limit_config_present():
    assert hasattr(settings, "RATE_LIMIT_AUTH")
    assert "/" in settings.RATE_LIMIT_AUTH


def test_limiter_on_auth_routes():
    # register endpoint should carry slowapi limit attributes when decorated
    assert hasattr(routes_mod, "limiter")
    assert routes_mod.register is not None

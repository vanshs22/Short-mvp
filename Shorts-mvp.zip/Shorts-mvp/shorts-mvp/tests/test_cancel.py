"""Job cancel + credit refund."""
from app.services import users as user_service
from app.services.pipeline import create_job, cancel_job, get_job
from app.models.schemas import CreateJobRequest, TemplateType, CaptionStyle, VoiceOption


def test_cancel_pending_job_refunds_credit():
    email = f"cancel_{id(object())}@example.com"
    user = user_service.create_user(email, "CancelTest1")
    before = user_service.usage_limits(user.id).credits_remaining
    # consume one credit as job create would
    assert user_service.check_and_consume_credit(user.id, 1)
    after_consume = user_service.usage_limits(user.id).credits_remaining
    assert after_consume == before - 1

    req = CreateJobRequest(
        template=TemplateType.STANDARD,
        script="Hello world this is a test script.",
        caption_style=CaptionStyle.CLASSIC,
        voice=VoiceOption.JENNY,
    )
    job = create_job(req, user_id=user.id)
    cancelled = cancel_job(job.id, user_id=user.id)
    assert cancelled.status.value == "cancelled"
    # refund
    final = user_service.usage_limits(user.id).credits_remaining
    assert final == before


def test_cancel_wrong_user():
    email = f"c2_{id(object())}@example.com"
    user = user_service.create_user(email, "CancelTest1")
    req = CreateJobRequest(script="Short text for cancel ownership test.")
    job = create_job(req, user_id=user.id)
    try:
        cancel_job(job.id, user_id="someone-else")
        assert False, "should have raised"
    except ValueError as e:
        assert "not your" in str(e).lower() or "Not your" in str(e)

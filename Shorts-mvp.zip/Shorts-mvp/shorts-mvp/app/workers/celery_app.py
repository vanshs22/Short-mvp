"""Celery application and tasks for Shorts MVP job queue."""
from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Any, Optional

from celery import Celery

from app.core.config import settings

logger = logging.getLogger(__name__)

celery_app = Celery(
    "shorts_mvp",
    broker=settings.CELERY_BROKER_URL or "redis://localhost:6379/0",
    backend=settings.CELERY_RESULT_BACKEND or "redis://localhost:6379/1",
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    task_time_limit=getattr(settings, "JOB_TIMEOUT_SECONDS", 600) + 60,
    worker_prefetch_multiplier=1,
)


@celery_app.task(name="run_pipeline_task", bind=True)
def run_pipeline_task(self, job_id: str, request_data: dict, upload_path: Optional[str] = None):
    """
    Celery entrypoint: reconstruct CreateJobRequest and run the async pipeline.
    """
    from app.models.schemas import CreateJobRequest
    from app.services.pipeline import run_pipeline

    try:
        request = CreateJobRequest.model_validate(request_data)
    except Exception:
        # pydantic v1 fallback
        request = CreateJobRequest.parse_obj(request_data)

    path = Path(upload_path) if upload_path else None
    logger.info("Celery task starting pipeline for job %s", job_id)

    try:
        asyncio.run(run_pipeline(job_id, request, path))
    except Exception as e:
        logger.exception("Pipeline failed for job %s: %s", job_id, e)
        raise

    return {"job_id": job_id, "status": "completed"}

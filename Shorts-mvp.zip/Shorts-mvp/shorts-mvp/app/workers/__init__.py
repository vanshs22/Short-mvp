"""Workers package  Celery app lives in celery_app module."""
from app.workers.celery_app import celery_app, run_pipeline_task

__all__ = ["celery_app", "run_pipeline_task"]

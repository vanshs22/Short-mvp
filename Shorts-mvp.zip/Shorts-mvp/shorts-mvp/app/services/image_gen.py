"""AI image generation for high-quality faceless reels.

Supports OpenAI Images API (DALL·E 3 / gpt-image) and any OpenAI-compatible
provider that exposes /images/generations (some OpenRouter routes).

Falls back to attractive gradient poster images when no key is configured
so the product still works offline.
"""
from __future__ import annotations

import base64
import logging
import re
from pathlib import Path
from typing import List, Optional

import httpx
from PIL import Image, ImageDraw, ImageFont

from app.core.config import settings

logger = logging.getLogger(__name__)

SCENE_SYSTEM = """You design vertical (9:16) scene prompts for faceless TikTok/Reels videos.
Given a spoken script, output 3 to 6 short image prompts (one per visual beat).
Rules:
- Each prompt is a single line, concrete, cinematic, no text/watermarks/logos in the image.
- Vertical composition friendly (portrait framing).
- Style: photoreal or clean illustration, high detail, dramatic lighting.
- No violence, gore, sexual content, or real celebrity likenesses.
- Output ONLY the prompts, one per line, no numbering unless natural."""


def image_gen_available() -> bool:
    return bool(settings.LLM_API_KEY and settings.IMAGE_GEN_ENABLED)


async def plan_scene_prompts(script: str, max_scenes: int = 5) -> List[str]:
    """Use LLM to turn a script into visual scene prompts."""
    script = (script or "").strip()
    if len(script) < 20:
        return _fallback_prompts(script or "abstract motivational background")

    if settings.LLM_API_KEY and settings.LLM_BASE_URL:
        try:
            headers = {
                "Authorization": f"Bearer {settings.LLM_API_KEY}",
                "Content-Type": "application/json",
            }
            # OpenRouter sometimes wants HTTP-Referer
            if "openrouter" in (settings.LLM_BASE_URL or "").lower():
                headers["HTTP-Referer"] = "https://shorts-mvp.local"
                headers["X-Title"] = "Shorts MVP"
            payload = {
                "model": settings.LLM_MODEL,
                "temperature": 0.7,
                "max_tokens": 500,
                "messages": [
                    {"role": "system", "content": SCENE_SYSTEM},
                    {
                        "role": "user",
                        "content": f"Max scenes: {max_scenes}\n\nScript:\n{script}\n\nScene prompts:",
                    },
                ],
            }
            url = settings.LLM_BASE_URL.rstrip("/") + "/chat/completions"
            async with httpx.AsyncClient(timeout=60.0) as client:
                r = await client.post(url, headers=headers, json=payload)
                r.raise_for_status()
                text = r.json()["choices"][0]["message"]["content"].strip()
            lines = []
            for line in text.splitlines():
                line = re.sub(r"^[\d\.\)\-\*]+\s*", "", line).strip()
                line = line.strip("`\"'")
                if len(line) > 12:
                    lines.append(line)
            if lines:
                return lines[:max_scenes]
        except Exception as e:
            logger.warning(f"Scene planning LLM failed: {e}")

    return _fallback_prompts(script, max_scenes)


def _fallback_prompts(script: str, max_scenes: int = 4) -> List[str]:
    words = re.findall(r"[A-Za-z]{4,}", script)[:8]
    topic = " ".join(words[:4]) if words else "focus and growth"
    base = [
        f"Cinematic vertical shot, {topic}, dramatic lighting, shallow depth of field, 9:16",
        f"Abstract modern background representing {topic}, soft gradients, premium look",
        f"Close-up detail related to {topic}, moody atmosphere, high quality photo",
        f"Wide atmospheric scene inspired by {topic}, golden hour, vertical composition",
        f"Minimal clean visual metaphor for {topic}, studio lighting, portrait frame",
    ]
    return base[:max_scenes]


async def generate_image(
    prompt: str,
    output_path: Path,
    *,
    size: str | None = None,
    quality: str | None = None,
) -> Path:
    """
    Generate one image to output_path (PNG).
    Uses OpenAI-compatible /images/generations when configured.
    """
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    size = size or settings.IMAGE_SIZE
    quality = quality or settings.IMAGE_QUALITY

    if image_gen_available():
        try:
            return await _openai_image(prompt, output_path, size=size, quality=quality)
        except Exception as e:
            logger.warning(f"AI image gen failed, using gradient fallback: {e}")

    return _gradient_poster(prompt, output_path)


async def generate_scene_images(
    prompts: List[str],
    work_dir: Path,
    *,
    prefix: str = "scene",
) -> List[Path]:
    """Generate one image per prompt. Returns list of paths (always non-empty)."""
    work_dir = Path(work_dir)
    work_dir.mkdir(parents=True, exist_ok=True)
    paths: List[Path] = []
    for i, p in enumerate(prompts):
        out = work_dir / f"{prefix}_{i:02d}.png"
        try:
            await generate_image(p, out)
            if out.exists() and out.stat().st_size > 500:
                paths.append(out)
        except Exception as e:
            logger.warning(f"Scene {i} failed: {e}")
    if not paths:
        # guarantee at least one
        out = work_dir / f"{prefix}_00.png"
        _gradient_poster(prompts[0] if prompts else "abstract", out)
        paths.append(out)
    return paths


async def _openai_image(prompt: str, output_path: Path, size: str, quality: str) -> Path:
    headers = {
        "Authorization": f"Bearer {settings.LLM_API_KEY}",
        "Content-Type": "application/json",
    }
    if "openrouter" in (settings.LLM_BASE_URL or "").lower():
        headers["HTTP-Referer"] = "https://shorts-mvp.local"
        headers["X-Title"] = "Shorts MVP"

    # Prefer dedicated image base if set, else LLM base
    base = (settings.IMAGE_BASE_URL or settings.LLM_BASE_URL or "https://api.openai.com/v1").rstrip("/")
    model = settings.IMAGE_MODEL

    # OpenAI Images API
    payload = {
        "model": model,
        "prompt": prompt[:4000],
        "n": 1,
        "size": size,
    }
    # gpt-image / dall-e-3 extras
    if "dall-e" in model or "gpt-image" in model:
        payload["quality"] = quality if quality in ("standard", "hd", "low", "medium", "high", "auto") else "standard"
        if "dall-e-3" in model:
            payload["response_format"] = "b64_json"

    url = base + "/images/generations"
    async with httpx.AsyncClient(timeout=120.0) as client:
        r = await client.post(url, headers=headers, json=payload)
        if r.status_code >= 400:
            # Some providers want different size strings
            logger.warning(f"Image API {r.status_code}: {r.text[:300]}")
            r.raise_for_status()
        data = r.json()

    item = data["data"][0]
    if item.get("b64_json"):
        raw = base64.b64decode(item["b64_json"])
        output_path.write_bytes(raw)
    elif item.get("url"):
        async with httpx.AsyncClient(timeout=60.0) as client:
            img = await client.get(item["url"])
            img.raise_for_status()
            output_path.write_bytes(img.content)
    else:
        raise RuntimeError("Image API returned no b64_json or url")

    # Ensure 9:16-ish for vertical reels (crop/pad)
    _ensure_portrait(output_path)
    return output_path


def _ensure_portrait(path: Path, target: tuple[int, int] = (1080, 1920)) -> None:
    try:
        im = Image.open(path).convert("RGB")
        tw, th = target
        scale = max(tw / im.width, th / im.height)
        nw, nh = int(im.width * scale), int(im.height * scale)
        im = im.resize((nw, nh), Image.Resampling.LANCZOS)
        left = (nw - tw) // 2
        top = (nh - th) // 2
        im = im.crop((left, top, left + tw, top + th))
        im.save(path, "PNG", optimize=True)
    except Exception as e:
        logger.warning(f"Portrait fit failed: {e}")


def _gradient_poster(prompt: str, output_path: Path, size: tuple[int, int] = (1080, 1920)) -> Path:
    """Attractive offline fallback: gradient + soft shapes + prompt hint."""
    w, h = size
    im = Image.new("RGB", (w, h))
    draw = ImageDraw.Draw(im)
    # Hash prompt into colors
    seed = sum(ord(c) for c in (prompt or "x")[:80]) or 1
    c1 = ((seed * 37) % 80 + 20, (seed * 17) % 60 + 20, (seed * 53) % 100 + 40)
    c2 = ((seed * 11) % 40 + 10, (seed * 29) % 50 + 30, (seed * 41) % 80 + 60)
    for y in range(h):
        t = y / max(h - 1, 1)
        r = int(c1[0] * (1 - t) + c2[0] * t)
        g = int(c1[1] * (1 - t) + c2[1] * t)
        b = int(c1[2] * (1 - t) + c2[2] * t)
        draw.line([(0, y), (w, y)], fill=(r, g, b))
    # Soft circles
    for i in range(5):
        cx = (seed * (i + 3) * 91) % w
        cy = (seed * (i + 7) * 53) % h
        rad = 120 + (seed * (i + 1)) % 200
        col = (255, 255, 255, 28)
        overlay = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        od = ImageDraw.Draw(overlay)
        od.ellipse([cx - rad, cy - rad, cx + rad, cy + rad], fill=col)
        im = Image.alpha_composite(im.convert("RGBA"), overlay).convert("RGB")
        draw = ImageDraw.Draw(im)
    # Tiny caption of first words (not the full prompt)
    try:
        font = ImageFont.load_default()
        snippet = re.sub(r"\s+", " ", prompt)[:42]
        draw.text((48, h - 120), snippet, fill=(220, 220, 230), font=font)
    except Exception:
        pass
    output_path.parent.mkdir(parents=True, exist_ok=True)
    im.save(output_path, "PNG", optimize=True)
    return output_path

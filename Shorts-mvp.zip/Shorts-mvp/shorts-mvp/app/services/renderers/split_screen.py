"""
Split-screen / streamer-style overlay.
Typical layout: top third = webcam/reaction placeholder, bottom = gameplay/content.
"""
from __future__ import annotations

import logging
import subprocess
from pathlib import Path
from typing import Optional

from PIL import Image, ImageDraw, ImageFont

from app.core.config import settings
from app.models.schemas import SplitScreenRequest

logger = logging.getLogger(__name__)

W = settings.TARGET_WIDTH
H = settings.TARGET_HEIGHT


def _font(size: int, bold: bool = False):
    for p in [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
    ]:
        if Path(p).exists():
            try:
                return ImageFont.truetype(p, size)
            except Exception:
                pass
    return ImageFont.load_default()


def render_webcam_placeholder(label: str, out_path: Path, width: int, height: int) -> Path:
    """Generate a simple webcam-style placeholder panel."""
    img = Image.new("RGB", (width, height), (28, 28, 32))
    draw = ImageDraw.Draw(img)
    # Circle avatar
    cx, cy = width // 2, height // 2 - 20
    r = min(width, height) // 5
    draw.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(60, 60, 70))
    # Label
    font = _font(36, bold=True)
    bb = draw.textbbox((0, 0), label, font=font)
    tw = bb[2] - bb[0]
    draw.text(((width - tw) // 2, cy + r + 24), label, font=font, fill=(200, 200, 210))
    # "LIVE" badge
    draw.rounded_rectangle([16, 16, 100, 48], radius=8, fill=(220, 38, 38))
    draw.text((28, 22), "LIVE", font=_font(18, bold=True), fill=(255, 255, 255))
    out_path.parent.mkdir(parents=True, exist_ok=True)
    img.save(out_path, "PNG")
    return out_path


def compose_split_screen(
    content_video: Path | None,
    audio_path: Path,
    srt_path: Path | None,
    output_path: Path,
    req: SplitScreenRequest,
    caption_style: str = "classic",
    duration: float | None = None,
) -> Path:
    """
    Compose top_bottom split:
      - Top ~38% : webcam placeholder (or secondary video later)
      - Bottom ~62% : content / gameplay loop
    """
    from app.services.video import _style_to_force_style

    if duration is None:
        probe = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration",
             "-of", "default=noprint_wrappers=1:nokey=1", str(audio_path)],
            capture_output=True, text=True,
        )
        duration = float(probe.stdout.strip())

    top_h = int(H * 0.38)
    bot_h = H - top_h
    work = output_path.parent
    cam_path = work / "webcam_placeholder.png"
    render_webcam_placeholder(req.top_label, cam_path, W, top_h)

    force_style = _style_to_force_style(caption_style)
    srt_filter = ""
    if srt_path and srt_path.exists():
        srt_esc = Path(srt_path).resolve().as_posix().replace(":", "\\:")
        if str(srt_path).lower().endswith(".ass"):
            srt_filter = f",ass='{srt_esc}'"
        else:
            srt_filter = f",subtitles='{srt_esc}':original_size={W}x{H}:force_style='{force_style}'"

    if content_video and content_video.exists():
        # Loop content for bottom panel
        fc = (
            f"[1:v]scale={W}:{bot_h}:force_original_aspect_ratio=increase,"
            f"crop={W}:{bot_h},loop=loop=-1:size=32767:start=0,setpts=N/FRAME_RATE/TB,"
            f"trim=duration={duration},setsar=1[bot];"
            f"[0:v]scale={W}:{top_h},setsar=1[top];"
            f"[top][bot]vstack=inputs=2[v]"
            f"{srt_filter.replace('[v]', '[v]').replace('subtitles', '[v]subtitles') if srt_filter else ''}"
        )
        # Cleaner approach without the broken replace:
        if srt_filter:
            fc = (
                f"[1:v]scale={W}:{bot_h}:force_original_aspect_ratio=increase,"
                f"crop={W}:{bot_h},loop=loop=-1:size=32767:start=0,setpts=N/FRAME_RATE/TB,"
                f"trim=duration={duration},setsar=1[bot];"
                f"[0:v]scale={W}:{top_h},setsar=1[top];"
                f"[top][bot]vstack=inputs=2[stacked];"
                f"[stacked]subtitles='{srt_esc}':force_style='{force_style}'[outv]"
            )
            map_v = "[outv]"
        else:
            fc = (
                f"[1:v]scale={W}:{bot_h}:force_original_aspect_ratio=increase,"
                f"crop={W}:{bot_h},loop=loop=-1:size=32767:start=0,setpts=N/FRAME_RATE/TB,"
                f"trim=duration={duration},setsar=1[bot];"
                f"[0:v]scale={W}:{top_h},setsar=1[top];"
                f"[top][bot]vstack=inputs=2[outv]"
            )
            map_v = "[outv]"

        cmd = [
            "ffmpeg", "-y",
            "-loop", "1", "-i", str(cam_path),
            "-stream_loop", "-1", "-i", str(content_video),
            "-i", str(audio_path),
            "-filter_complex", fc,
            "-map", map_v, "-map", "2:a",
            "-c:v", "libx264", "-preset", "medium", "-crf", "22",
            "-c:a", "aac", "-b:a", "192k",
            "-t", str(duration),
            "-movflags", "+faststart",
            str(output_path),
        ]
    else:
        # Solid bottom panel
        if srt_path and srt_path.exists():
            srt_esc = Path(srt_path).resolve().as_posix().replace(":", "\\:")
            fc = (
                f"[0:v]scale={W}:{top_h},setsar=1[top];"
                f"color=c=0x14141e:s={W}x{bot_h}:d={duration}[bot];"
                f"[top][bot]vstack=inputs=2[stacked];"
                f"[stacked]subtitles='{srt_esc}':force_style='{force_style}'[outv]"
            )
        else:
            fc = (
                f"[0:v]scale={W}:{top_h},setsar=1[top];"
                f"color=c=0x14141e:s={W}x{bot_h}:d={duration}[bot];"
                f"[top][bot]vstack=inputs=2[outv]"
            )
        cmd = [
            "ffmpeg", "-y",
            "-loop", "1", "-i", str(cam_path),
            "-i", str(audio_path),
            "-filter_complex", fc,
            "-map", "[outv]", "-map", "1:a",
            "-c:v", "libx264", "-preset", "medium", "-crf", "22",
            "-c:a", "aac", "-b:a", "192k",
            "-t", str(duration),
            "-movflags", "+faststart",
            str(output_path),
        ]

    logger.info("Composing split-screen video...")
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        logger.error(result.stderr[-1000:])
        raise RuntimeError(f"Split-screen compose failed: {result.stderr[-400:]}")
    return output_path

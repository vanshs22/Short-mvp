"""
Reddit Story template renderer.
Produces a static (or lightly animated) Reddit post card image,
then composites it over a gameplay background with voice + captions.
"""
from __future__ import annotations

import logging
import textwrap
from pathlib import Path
from typing import Optional, Tuple

from PIL import Image, ImageDraw, ImageFont

from app.core.config import settings
from app.models.schemas import RedditStoryRequest

logger = logging.getLogger(__name__)

# Card design constants (9:16 friendly)
CARD_W = 980
CARD_PAD = 36
BG_COLOR = (26, 26, 27)          # Reddit dark
CARD_BG = (30, 30, 32)
TEXT_PRIMARY = (215, 218, 220)
TEXT_SECONDARY = (129, 131, 132)
ACCENT = (255, 69, 0)            # Reddit orange
UPVOTE_ORANGE = (255, 69, 0)
LINE = (60, 60, 62)


def _load_font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
        "/usr/share/fonts/truetype/freefont/FreeSansBold.ttf" if bold else "/usr/share/fonts/truetype/freefont/FreeSans.ttf",
    ]
    for path in candidates:
        if Path(path).exists():
            try:
                return ImageFont.truetype(path, size)
            except Exception:
                continue
    return ImageFont.load_default()


def _wrap(text: str, font: ImageFont.ImageFont, max_width: int) -> list[str]:
    """Word-wrap text to fit max_width pixels."""
    words = text.split()
    lines: list[str] = []
    current = ""
    draw = ImageDraw.Draw(Image.new("RGB", (1, 1)))
    for w in words:
        test = f"{current} {w}".strip()
        bbox = draw.textbbox((0, 0), test, font=font)
        if bbox[2] - bbox[0] <= max_width:
            current = test
        else:
            if current:
                lines.append(current)
            current = w
    if current:
        lines.append(current)
    return lines or [""]


def render_reddit_card(
    req: RedditStoryRequest,
    output_path: Path,
    max_body_lines: int = 18,
) -> Path:
    """
    Render a Reddit-style post card as a PNG.
    Height is dynamic based on content; width is fixed for 9:16 overlay.
    """
    font_sub = _load_font(22)
    font_user = _load_font(24)
    font_title = _load_font(36, bold=True)
    font_body = _load_font(28)
    font_meta = _load_font(22)

    content_w = CARD_W - 2 * CARD_PAD

    # Measure
    title_lines = _wrap(req.title, font_title, content_w)
    body_lines = _wrap(req.body, font_body, content_w)[:max_body_lines]
    if len(_wrap(req.body, font_body, content_w)) > max_body_lines:
        body_lines[-1] = body_lines[-1][: max(0, len(body_lines[-1]) - 3)] + "..."

    line_h_title = 44
    line_h_body = 36
    header_h = 70
    footer_h = 60
    gap = 16

    total_h = (
        CARD_PAD
        + header_h
        + gap
        + len(title_lines) * line_h_title
        + gap
        + len(body_lines) * line_h_body
        + gap
        + footer_h
        + CARD_PAD
    )

    img = Image.new("RGBA", (CARD_W, total_h), (*CARD_BG, 255))
    draw = ImageDraw.Draw(img)

    # Subtle top accent bar
    draw.rectangle([0, 0, CARD_W, 4], fill=ACCENT)

    y = CARD_PAD + 8

    # Subreddit + username
    draw.text((CARD_PAD, y), req.subreddit, font=font_sub, fill=ACCENT)
    sub_bbox = draw.textbbox((CARD_PAD, y), req.subreddit, font=font_sub)
    draw.text((sub_bbox[2] + 12, y), f"•  {req.username}", font=font_user, fill=TEXT_SECONDARY)
    y += header_h - 20

    # Title
    for line in title_lines:
        draw.text((CARD_PAD, y), line, font=font_title, fill=TEXT_PRIMARY)
        y += line_h_title
    y += gap // 2

    # Divider
    draw.line([(CARD_PAD, y), (CARD_W - CARD_PAD, y)], fill=LINE, width=1)
    y += gap

    # Body
    for line in body_lines:
        draw.text((CARD_PAD, y), line, font=font_body, fill=TEXT_PRIMARY)
        y += line_h_body
    y += gap

    # Footer: upvotes
    draw.text((CARD_PAD, y), f"▲  {req.upvotes}", font=font_meta, fill=UPVOTE_ORANGE)
    if req.awards > 0:
        draw.text((CARD_PAD + 160, y), f"🏆 {req.awards}", font=font_meta, fill=TEXT_SECONDARY)

    # Rounded corners via mask
    mask = Image.new("L", (CARD_W, total_h), 0)
    mask_draw = ImageDraw.Draw(mask)
    radius = 24
    mask_draw.rounded_rectangle([0, 0, CARD_W, total_h], radius=radius, fill=255)
    output = Image.new("RGBA", (CARD_W, total_h), (0, 0, 0, 0))
    output.paste(img, mask=mask)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output.save(output_path, "PNG")
    logger.info(f"Reddit card rendered → {output_path} ({CARD_W}x{total_h})")
    return output_path


def reddit_script_from_request(req: RedditStoryRequest) -> str:
    """Build a natural narration script from the Reddit post."""
    # Clean body a bit for speech
    body = req.body.replace("\n", " ").strip()
    return f"{req.title}. {body}"

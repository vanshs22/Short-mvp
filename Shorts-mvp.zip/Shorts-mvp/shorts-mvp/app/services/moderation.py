"""Basic content moderation / abuse prevention (Phase 3–4)."""
from __future__ import annotations

import re
from typing import Optional

# Minimal blocklist – expand from policy / external service in production
BLOCKED_PATTERNS = [
    r"\b(kill\s+yourself|kys)\b",
    r"\b(child\s*porn|csam)\b",
    r"\b(how\s+to\s+make\s+(a\s+)?bomb)\b",
]

SUSPICIOUS_PATTERNS = [
    r"https?://\S{30,}",  # long raw URLs spam
]


def check_text(text: str) -> Optional[str]:
    """Return rejection reason or None if OK."""
    if not text or not text.strip():
        return None
    lower = text.lower()
    for pat in BLOCKED_PATTERNS:
        if re.search(pat, lower, re.I):
            return "Content violates policy (blocked phrase)."
    # Soft limits
    if len(text) > 15000:
        return "Text too long (max 15000 chars)."
    return None


def check_job_payload(script: str | None, reddit_body: str | None, fake_messages: list | None) -> Optional[str]:
    chunks = []
    if script:
        chunks.append(script)
    if reddit_body:
        chunks.append(reddit_body)
    if fake_messages:
        for m in fake_messages:
            if isinstance(m, dict):
                chunks.append(m.get("text") or "")
            else:
                chunks.append(getattr(m, "text", "") or "")
    for c in chunks:
        reason = check_text(c)
        if reason:
            return reason
    return None

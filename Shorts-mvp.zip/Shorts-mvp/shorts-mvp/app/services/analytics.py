"""Simple analytics event store (Phase 4). Swap for PostHog/Mixpanel later."""
from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional

from sqlalchemy import Column, String, DateTime, Text, Integer
from sqlalchemy.orm import Session

from app.db.database import Base, SessionLocal, engine

class AnalyticsEvent(Base):
    __tablename__ = "analytics_events"
    id = Column(String, primary_key=True)
    user_id = Column(String, nullable=True, index=True)
    event = Column(String, nullable=False, index=True)
    properties = Column(Text, default="{}")
    created_at = Column(DateTime, default=datetime.utcnow)


def ensure_analytics_table():
    Base.metadata.create_all(bind=engine, tables=[AnalyticsEvent.__table__])


def track(event: str, user_id: str | None = None, **props):
    import json
    ensure_analytics_table()
    db = SessionLocal()
    try:
        row = AnalyticsEvent(
            id=str(uuid.uuid4()),
            user_id=user_id,
            event=event,
            properties=json.dumps(props or {}),
            created_at=datetime.utcnow(),
        )
        db.add(row)
        db.commit()
    finally:
        db.close()


def recent_events(limit: int = 50, user_id: str | None = None) -> List[dict]:
    import json
    ensure_analytics_table()
    db = SessionLocal()
    try:
        q = db.query(AnalyticsEvent).order_by(AnalyticsEvent.created_at.desc())
        if user_id:
            q = q.filter(AnalyticsEvent.user_id == user_id)
        rows = q.limit(limit).all()
        return [
            {
                "id": r.id,
                "event": r.event,
                "user_id": r.user_id,
                "properties": json.loads(r.properties or "{}"),
                "created_at": r.created_at.isoformat() if r.created_at else None,
            }
            for r in rows
        ]
    finally:
        db.close()


def summary() -> dict:
    ensure_analytics_table()
    db = SessionLocal()
    try:
        from sqlalchemy import func
        total = db.query(func.count(AnalyticsEvent.id)).scalar() or 0
        by_event = (
            db.query(AnalyticsEvent.event, func.count(AnalyticsEvent.id))
            .group_by(AnalyticsEvent.event)
            .all()
        )
        return {"total_events": total, "by_event": {e: c for e, c in by_event}}
    finally:
        db.close()

"""Email via Resend API (preferred) or SMTP. Console fallback if neither configured."""
from __future__ import annotations

import logging
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import Optional

from app.core.config import settings

logger = logging.getLogger(__name__)


def _wrap_html(title: str, body_html: str) -> str:
    return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>{title}</title></head>
<body style="margin:0;padding:0;background:#0a0a0f;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#0a0a0f;padding:32px 16px;">
    <tr><td align="center">
      <table width="560" cellpadding="0" cellspacing="0" style="background:#18181b;border-radius:12px;padding:32px;border:1px solid #27272a;">
        <tr><td style="color:#a5b4fc;font-size:14px;font-weight:600;letter-spacing:0.05em;">SHORTS MVP</td></tr>
        <tr><td style="color:#fafafa;font-size:22px;font-weight:700;padding-top:12px;">{title}</td></tr>
        <tr><td style="color:#a1a1aa;font-size:15px;line-height:1.6;padding-top:16px;">{body_html}</td></tr>
        <tr><td style="color:#52525b;font-size:12px;padding-top:28px;border-top:1px solid #27272a;">
          You’re receiving this because you have a Shorts MVP account.
        </td></tr>
      </table>
    </td></tr>
  </table>
</body></html>"""


def send_email(to: str, subject: str, body: str, html: str | None = None) -> bool:
    if settings.RESEND_API_KEY:
        return _send_resend(to, subject, body, html)
    if settings.SMTP_HOST:
        return _send_smtp(to, subject, body, html)
    logger.info(f"[email:console] to={to} subject={subject}\n{body[:500]}")
    return True


def _send_resend(to: str, subject: str, body: str, html: str | None = None) -> bool:
    try:
        import httpx
        payload = {
            "from": settings.SMTP_FROM,
            "to": [to],
            "subject": subject,
            "text": body,
        }
        if html:
            payload["html"] = html
        r = httpx.post(
            "https://api.resend.com/emails",
            headers={
                "Authorization": f"Bearer {settings.RESEND_API_KEY}",
                "Content-Type": "application/json",
            },
            json=payload,
            timeout=20,
        )
        if r.status_code >= 400:
            logger.error(f"Resend error {r.status_code}: {r.text[:300]}")
            return False
        logger.info(f"Resend OK → {to} id={r.json().get('id')}")
        return True
    except Exception as e:
        logger.error(f"Resend failed: {e}")
        return False


def _send_smtp(to: str, subject: str, body: str, html: str | None = None) -> bool:
    try:
        if html:
            msg = MIMEMultipart("alternative")
            msg.attach(MIMEText(body, "plain", "utf-8"))
            msg.attach(MIMEText(html, "html", "utf-8"))
        else:
            msg = MIMEText(body, "plain", "utf-8")
        msg["Subject"] = subject
        msg["From"] = settings.SMTP_FROM
        msg["To"] = to
        port = int(settings.SMTP_PORT)
        with smtplib.SMTP(settings.SMTP_HOST, port, timeout=20) as s:
            s.starttls()
            user = settings.SMTP_USER or "resend"
            password = settings.SMTP_PASSWORD or settings.RESEND_API_KEY
            if password:
                s.login(user, password)
            s.send_message(msg)
        logger.info(f"SMTP OK → {to}")
        return True
    except Exception as e:
        logger.error(f"SMTP failed: {e}")
        return False


def notify_job_complete(email: str, job_id: str, output_url: str):
    text = f"Job {job_id} completed.\n\nDownload: {output_url}\n\n— Shorts MVP"
    html = _wrap_html(
        "Your short is ready",
        f"<p>Job <code style='color:#e4e4e7'>{job_id}</code> finished successfully.</p>"
        f"<p style='padding-top:12px'><a href='{output_url}' style='display:inline-block;background:#6366f1;color:#fff;"
        f"text-decoration:none;padding:10px 18px;border-radius:8px;font-weight:600'>Download video</a></p>"
        f"<p style='padding-top:12px;font-size:13px'>If the button doesn’t work, open:<br>{output_url}</p>",
    )
    send_email(email, "Your short is ready", text, html)


def notify_welcome(email: str, name: str | None):
    text = (
        f"Hi {name or 'there'},\n\n"
        "Your account is ready. You have starter credits to generate vertical shorts.\n\n— Shorts MVP"
    )
    html = _wrap_html(
        f"Welcome{', ' + name if name else ''}!",
        "<p>Your account is ready. You’ve received starter credits to create vertical shorts "
        "with captions, voiceover, and viral templates.</p>"
        "<p style='padding-top:8px'>Open the app, paste a script or pick a template, and hit generate.</p>",
    )
    send_email(email, "Welcome to Shorts MVP", text, html)


def notify_low_credits(email: str, remaining: int):
    text = f"You have {remaining} credits left. Top up or upgrade from Billing.\n\n— Shorts MVP"
    html = _wrap_html(
        "Running low on credits",
        f"<p>You have <strong style='color:#fafafa'>{remaining}</strong> credits remaining.</p>"
        "<p style='padding-top:8px'>Buy a credit pack or upgrade to Pro / Studio to keep creating without interruption.</p>",
    )
    send_email(email, "Low credits on Shorts MVP", text, html)

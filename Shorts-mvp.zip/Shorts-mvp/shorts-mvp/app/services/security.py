"""Cross-cutting security helpers: ownership, URL safety, ffmpeg path escape."""
from __future__ import annotations

import ipaddress
import re
from typing import Optional
from urllib.parse import urlparse

from fastapi import HTTPException

from app.models.schemas import JobResponse, UserResponse


def assert_job_access(job: JobResponse, user: Optional[UserResponse], *, write: bool = False) -> None:
    """
    Jobs with a user_id are private to that user.
    Anonymous jobs (no user_id) are readable by anyone who knows the UUID
    (treat UUID as capability token). Writes still require matching owner if set.
    """
    if not job.user_id:
        return  # capability-URL style anonymous job
    if not user:
        raise HTTPException(401, "Authentication required to access this job")
    if user.id != job.user_id:
        raise HTTPException(403, "Not your job")


def escape_ffmpeg_path(path: str) -> str:
    """Escape a filesystem path for use inside FFmpeg filtergraphs."""
    return (
        str(path)
        .replace("\\", "/")
        .replace(":", "\\:")
        .replace("'", r"\'")
        .replace(",", r"\,")
        .replace("[", r"\[")
        .replace("]", r"\]")
    )


_BLOCKED_HOST_PATTERNS = re.compile(
    r"^(localhost|127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|0\.0\.0\.0|::1|metadata\.google|169\.254\.)",
    re.I,
)


def assert_safe_external_url(url: str, *, allow_hosts: tuple[str, ...] = ()) -> str:
    """
    Basic SSRF guard for user-supplied URLs (YouTube downloads).
    Rejects file://, internal IPs, localhost, link-local, cloud metadata.
    """
    url = (url or "").strip()
    if not url:
        raise HTTPException(400, "URL required")
    lower = url.lower()
    if lower.startswith("file:") or lower.startswith("ftp:") or lower.startswith("gopher:"):
        raise HTTPException(400, "Only http/https URLs allowed")
    if "://" in url and not (lower.startswith("http://") or lower.startswith("https://")):
        raise HTTPException(400, "Only http/https URLs allowed")
    if not url.startswith("http://") and not url.startswith("https://"):
        url = "https://" + url
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        raise HTTPException(400, "Only http/https URLs allowed")
    host = (parsed.hostname or "").lower()
    if not host:
        raise HTTPException(400, "Invalid URL host")
    if _BLOCKED_HOST_PATTERNS.match(host):
        raise HTTPException(400, "URL host not allowed")
    try:
        # If host is a raw IP, check private ranges
        ip = ipaddress.ip_address(host)
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved:
            raise HTTPException(400, "URL host not allowed")
    except ValueError:
        pass  # hostname not an IP – OK
    if allow_hosts:
        if not any(host == h or host.endswith("." + h) for h in allow_hosts):
            raise HTTPException(400, f"Host not allowed. Use: {', '.join(allow_hosts)}")
    # Block credentials in URL
    if parsed.username or parsed.password:
        raise HTTPException(400, "URL must not contain credentials")
    return url

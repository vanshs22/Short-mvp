"""Canonical product catalog: 3 tiers + credit packs.

Higher plan → more monthly credits, higher concurrent renders, larger batch/storage.
"""
from __future__ import annotations

from app.core.config import settings


def plan_catalog() -> dict:
    """Public pricing used by API + UI."""
    return {
        "plans": [
            {
                "id": "free",
                "name": "Free",
                "price_cents": 0,
                "price_label": "$0",
                "interval": None,
                "credits_monthly": settings.FREE_CREDITS,
                "credits_on_join": settings.FREE_CREDITS,
                "max_concurrent_jobs": getattr(settings, "FREE_CONCURRENT_JOBS", 2),
                "max_videos_per_week": settings.FREE_VIDEOS_PER_WEEK,
                "max_batch_size": settings.FREE_BATCH_SIZE,
                "storage_mb": settings.FREE_STORAGE_MB,
                "checkout_kind": None,
                "blurb": "Try the product — limited concurrent renders",
            },
            {
                "id": "pro",
                "name": "Creator",
                "price_cents": settings.PRO_PRICE_CENTS,
                "price_label": f"${settings.PRO_PRICE_CENTS // 100}/mo",
                "interval": "month",
                "credits_monthly": settings.PRO_CREDITS_MONTHLY,
                "max_concurrent_jobs": getattr(settings, "PRO_CONCURRENT_JOBS", 5),
                "max_videos_per_week": settings.PRO_VIDEOS_PER_WEEK,
                "max_batch_size": settings.PRO_BATCH_SIZE,
                "storage_mb": settings.PRO_STORAGE_MB,
                "checkout_kind": "subscription_pro",
                "blurb": "For regular creators — more credits & parallel jobs",
            },
            {
                "id": "studio",
                "name": "Studio",
                "price_cents": settings.STUDIO_PRICE_CENTS,
                "price_label": f"${settings.STUDIO_PRICE_CENTS // 100}/mo",
                "interval": "month",
                "credits_monthly": settings.STUDIO_CREDITS_MONTHLY,
                "max_concurrent_jobs": getattr(settings, "STUDIO_CONCURRENT_JOBS", 15),
                "max_videos_per_week": 9999,
                "max_batch_size": settings.STUDIO_BATCH_SIZE,
                "storage_mb": settings.STUDIO_STORAGE_MB,
                "checkout_kind": "subscription_studio",
                "blurb": "Teams & high volume — max credits & concurrency",
            },
        ],
        "packs": [
            {
                "id": k,
                "name": v["label"],
                "credits": v["credits"],
                "price_cents": v["price_cents"],
                "price_label": f"${v['price_cents'] // 100}",
                "checkout_kind": k,
                "blurb": f"{v['credits']} credits — one-time",
            }
            for k, v in settings.CREDIT_PACKS.items()
        ],
    }


def resolve_checkout_kind(kind: str) -> dict:
    """
    Normalize kind → grant instructions.
    Returns {type: plan|pack, plan?, credits?, amount_cents, label}
    """
    kind = (kind or "").strip()
    if kind == "subscription_pro" or kind == "pro":
        return {
            "type": "plan",
            "plan": "pro",
            "credits": settings.PRO_CREDITS_MONTHLY,
            "amount_cents": settings.PRO_PRICE_CENTS,
            "label": "Creator plan",
            "kind": "subscription_pro",
        }
    if kind == "subscription_studio" or kind == "studio":
        return {
            "type": "plan",
            "plan": "studio",
            "credits": settings.STUDIO_CREDITS_MONTHLY,
            "amount_cents": settings.STUDIO_PRICE_CENTS,
            "label": "Studio plan",
            "kind": "subscription_studio",
        }
    if kind in settings.CREDIT_PACKS:
        p = settings.CREDIT_PACKS[kind]
        return {
            "type": "pack",
            "plan": None,
            "credits": p["credits"],
            "amount_cents": p["price_cents"],
            "label": p["label"],
            "kind": kind,
        }
    raise ValueError(f"Unknown product kind: {kind}")


def concurrent_limit_for_plan(plan: str) -> int:
    return {
        "free": getattr(settings, "FREE_CONCURRENT_JOBS", 2),
        "pro": getattr(settings, "PRO_CONCURRENT_JOBS", 5),
        "studio": getattr(settings, "STUDIO_CONCURRENT_JOBS", 15),
    }.get(plan or "free", 2)

"""Enqueue jobs on Celery/Redis when available, else FastAPI BackgroundTasks."""
from __future__ import annotations

import logging
from typing import Any, Callable, Optional

from app.core.config import settings

logger = logging.getLogger(__name__)


def redis_available() -> bool:
    url = settings.CELERY_BROKER_URL or ""
    if not url.startswith("redis"):
        return False
    try:
        import redis
        # redis://[:password@]host:port/db
        r = redis.from_url(url, socket_connect_timeout=1)
        r.ping()
        return True
    except Exception as e:
        logger.warning(f"Redis not reachable: {e}")
        return False


def enqueue_pipeline(background_tasks, job_id: str, request, upload_path=None) -> str:
    """
    Prefer Celery if Redis is up; otherwise BackgroundTasks.
    request: CreateJobRequest pydantic model
    """
    if redis_available():
        try:
            from app.workers.celery_app import run_pipeline_task
            data = request.model_dump() if hasattr(request, "model_dump") else request.dict()
            # Enums → values
            for k, v in list(data.items()):
                if hasattr(v, "value"):
                    data[k] = v.value
                elif isinstance(v, dict):
                    data[k] = {
                        kk: (vv.value if hasattr(vv, "value") else vv) for kk, vv in v.items()
                    } if v else v
            path = str(upload_path) if upload_path else None
            run_pipeline_task.delay(job_id, data, path)
            logger.info(f"Job {job_id} enqueued on Celery")
            try:
                from app.services import users as user_service
                from app.services.jobs import update_job  # type: ignore
            except Exception:
                update_job = None
            try:
                # Prefer jobs service if present
                from app.services import jobs as jobs_service
                if hasattr(jobs_service, "update_job"):
                    jobs_service.update_job(job_id, message="Queued on Celery workers", status="pending")
            except Exception:
                pass
            return "celery"
        except Exception as e:
            logger.warning(f"Celery enqueue failed ({e}); using BackgroundTasks")

    from app.services.pipeline import run_pipeline
    background_tasks.add_task(run_pipeline, job_id, request, upload_path)
    return "background"

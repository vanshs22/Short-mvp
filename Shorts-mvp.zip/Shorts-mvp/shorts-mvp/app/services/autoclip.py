"""
Auto-clip / highlight detection from long videos.
Uses silence gaps + audio energy windows via FFmpeg. Good MVP for main moments.
"""
from __future__ import annotations

import logging
import struct
import subprocess
import wave
from pathlib import Path
from typing import List, Tuple

logger = logging.getLogger(__name__)


def detect_highlights(
    video_path: Path,
    max_clips: int = 5,
    min_clip_sec: float = 12.0,
    max_clip_sec: float = 45.0,
    target_total_sec: float = 180.0,
) -> List[Tuple[float, float]]:
    """Return list of (start, end) pairs ranked by interest (energy + length)."""
    wav = video_path.parent / f"{video_path.stem}_analyze.wav"
    # Analyze up to 30 min to keep CPU reasonable
    subprocess.run(
        ["ffmpeg", "-y", "-i", str(video_path), "-vn", "-ac", "1", "-ar", "8000",
         "-t", "1800", str(wav)],
        capture_output=True, check=False,
    )
    duration = _probe_duration(video_path)
    if duration <= 0:
        duration = 60.0

    if not wav.exists() or wav.stat().st_size < 1000:
        return _even_slices(duration, max_clips, min_clip_sec, max_clip_sec)

    intervals = _non_silent_intervals(wav, duration, min_clip_sec, max_clip_sec)
    if not intervals:
        intervals = _even_slices(duration, max_clips, min_clip_sec, max_clip_sec)

    # Score by RMS energy inside each window
    scored: List[Tuple[float, float, float]] = []
    for start, end in intervals:
        energy = _window_energy(wav, start, end)
        length = end - start
        # Prefer energetic mid-length clips
        score = energy * (1.0 + min(length, max_clip_sec) / max_clip_sec)
        scored.append((score, start, end))

    scored.sort(reverse=True)
    clips: List[Tuple[float, float]] = []
    total = 0.0
    used_spans: List[Tuple[float, float]] = []

    for score, start, end in scored:
        length = end - start
        if length < min_clip_sec * 0.8:
            continue
        if length > max_clip_sec:
            # Keep the highest-energy subwindow of max_clip_sec
            start, end = _best_subwindow(wav, start, end, max_clip_sec)
            length = end - start
        # Avoid heavy overlap with already chosen clips
        if any(_overlap(start, end, a, b) > 0.5 * min(length, b - a) for a, b in used_spans):
            continue
        clips.append((round(start, 2), round(end, 2)))
        used_spans.append((start, end))
        total += length
        if len(clips) >= max_clips or total >= target_total_sec:
            break

    wav.unlink(missing_ok=True)
    if not clips:
        return _even_slices(duration, max_clips, min_clip_sec, max_clip_sec)
    # Return in timeline order for nicer UX
    clips.sort(key=lambda x: x[0])
    return clips


def extract_clip(video_path: Path, start: float, end: float, out_path: Path) -> Path:
    subprocess.run(
        [
            "ffmpeg", "-y", "-ss", str(start), "-to", str(end),
            "-i", str(video_path),
            "-c:v", "libx264", "-preset", "fast", "-crf", "23",
            "-c:a", "aac", "-movflags", "+faststart",
            str(out_path),
        ],
        capture_output=True, check=True,
    )
    return out_path


def extract_vertical_clip(
    video_path: Path,
    start: float,
    end: float,
    out_path: Path,
    width: int = 1080,
    height: int = 1920,
) -> Path:
    """Crop/scale to 9:16 vertical short."""
    duration = max(0.5, end - start)
    vf = (
        f"scale={width}:{height}:force_original_aspect_ratio=increase,"
        f"crop={width}:{height},setsar=1"
    )
    subprocess.run(
        [
            "ffmpeg", "-y",
            "-ss", str(start),
            "-i", str(video_path),
            "-t", str(duration),
            "-vf", vf,
            "-c:v", "libx264", "-preset", "fast", "-crf", "23",
            "-c:a", "aac", "-b:a", "192k",
            "-movflags", "+faststart",
            str(out_path),
        ],
        capture_output=True, check=True,
    )
    return out_path


def _probe_duration(path: Path) -> float:
    r = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "default=noprint_wrappers=1:nokey=1", str(path)],
        capture_output=True, text=True,
    )
    try:
        return float(r.stdout.strip())
    except Exception:
        return 0.0


def _non_silent_intervals(
    wav: Path, duration: float, min_clip_sec: float, max_clip_sec: float
) -> List[Tuple[float, float]]:
    result = subprocess.run(
        ["ffmpeg", "-i", str(wav), "-af", "silencedetect=noise=-30dB:d=0.45", "-f", "null", "-"],
        capture_output=True, text=True,
    )
    stderr = result.stderr or ""
    silences: List[Tuple[str, float]] = []
    for line in stderr.splitlines():
        if "silence_start:" in line:
            try:
                silences.append(("start", float(line.split("silence_start:")[1].strip().split()[0])))
            except Exception:
                pass
        if "silence_end:" in line:
            try:
                silences.append(("end", float(line.split("silence_end:")[1].strip().split()[0])))
            except Exception:
                pass

    silence_ranges: List[Tuple[float, float]] = []
    i = 0
    while i < len(silences):
        if silences[i][0] == "start":
            s = silences[i][1]
            e = duration
            if i + 1 < len(silences) and silences[i + 1][0] == "end":
                e = silences[i + 1][1]
                i += 1
            silence_ranges.append((s, e))
        i += 1

    intervals: List[Tuple[float, float]] = []
    t = 0.0
    for s, e in silence_ranges:
        if s - t >= min_clip_sec * 0.4:
            intervals.append((t, min(s, t + max_clip_sec * 1.5)))
        t = e
    if duration - t >= min_clip_sec * 0.4:
        intervals.append((t, min(duration, t + max_clip_sec * 1.5)))
    return intervals


def _window_energy(wav_path: Path, start: float, end: float) -> float:
    try:
        with wave.open(str(wav_path), "rb") as w:
            rate = w.getframerate()
            n = w.getnframes()
            s0 = max(0, int(start * rate))
            s1 = min(n, int(end * rate))
            if s1 <= s0:
                return 0.0
            w.setpos(s0)
            raw = w.readframes(s1 - s0)
        # 16-bit mono
        count = len(raw) // 2
        if count == 0:
            return 0.0
        samples = struct.unpack(f"<{count}h", raw[: count * 2])
        acc = sum(abs(x) for x in samples)
        return acc / count
    except Exception:
        return 1.0


def _best_subwindow(wav: Path, start: float, end: float, window: float) -> Tuple[float, float]:
    if end - start <= window:
        return start, end
    step = max(1.0, window / 4)
    best = (0.0, start, start + window)
    t = start
    while t + window <= end + 0.01:
        e = _window_energy(wav, t, t + window)
        if e > best[0]:
            best = (e, t, t + window)
        t += step
    return best[1], best[2]


def _overlap(a0: float, a1: float, b0: float, b1: float) -> float:
    return max(0.0, min(a1, b1) - max(a0, b0))


def _even_slices(
    duration: float, max_clips: int, min_clip_sec: float, max_clip_sec: float
) -> List[Tuple[float, float]]:
    clip_len = min(max_clip_sec, max(min_clip_sec, duration / max(1, max_clips)))
    clips = []
    t = 0.0
    while t < duration - min_clip_sec * 0.5 and len(clips) < max_clips:
        end = min(duration, t + clip_len)
        clips.append((round(t, 2), round(end, 2)))
        t += clip_len * 0.9
    return clips or [(0.0, min(duration, max_clip_sec))]

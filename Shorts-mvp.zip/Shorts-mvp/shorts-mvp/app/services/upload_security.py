"""File upload validation: size, extension, content-type, magic bytes."""
from __future__ import annotations

from pathlib import Path
from typing import Optional, Set

from fastapi import HTTPException, UploadFile

from app.core.config import settings

# Allowed media for video/audio uploads
VIDEO_EXTS: Set[str] = {".mp4", ".mov", ".webm", ".mkv", ".m4v"}
AUDIO_EXTS: Set[str] = {".mp3", ".wav", ".m4a", ".aac", ".ogg"}
IMAGE_EXTS: Set[str] = {".png", ".jpg", ".jpeg", ".webp"}

ALLOWED_UPLOAD_EXTS = VIDEO_EXTS | AUDIO_EXTS
ALLOWED_BACKGROUND_EXTS = VIDEO_EXTS

# Magic-byte signatures (first bytes)
MAGIC = {
    b"\x00\x00\x00\x18ftyp": "mp4",
    b"\x00\x00\x00\x1cftyp": "mp4",
    b"\x00\x00\x00\x20ftyp": "mp4",
    b"\x00\x00\x00\x14ftyp": "mp4",
    b"\x1aE\xdf\xa3": "webm/mkv",
    b"RIFF": "wav/avi",
    b"ID3": "mp3",
    b"\xff\xfb": "mp3",
    b"\xff\xf3": "mp3",
    b"\xff\xf2": "mp3",
    b"OggS": "ogg",
    b"\x89PNG": "png",
    b"\xff\xd8\xff": "jpeg",
    # webp starts with RIFF....WEBP
}


def _ext(filename: str) -> tuple[str, str]:
    return Path(filename).suffix.lower()


def _looks_like_media(header: bytes) -> bool:
    if len(header) < 4:
        return False
    for sig in MAGIC:
        if header.startswith(sig):
            return True
    # ftyp can sit a few bytes in
    if b"ftyp" in header[:32]:
        return True
    return False


def validate_upload(
    file: UploadFile,
    content: bytes,
    *,
    allowed_exts: Optional[Set[str]] = None,
    max_mb: Optional[int] = None,
) -> tuple[str, str]:
    """
    Validate uploaded file. Returns sanitized extension (with dot).
    Raises HTTPException on failure.
    """
    if not file.filename:
        raise HTTPException(400, "Missing filename")

    allowed = allowed_exts or ALLOWED_UPLOAD_EXTS
    max_bytes = (max_mb or settings.MAX_UPLOAD_SIZE_MB) * 1024 * 1024

    ext = _ext(file.filename)
    if ext not in allowed:
        raise HTTPException(
            400,
            f"File type '{ext}' not allowed. Allowed: {', '.join(sorted(allowed))}",
        )

    if len(content) == 0:
        raise HTTPException(400, "Empty file")
    if len(content) > max_bytes:
        raise HTTPException(413, f"File too large (max {max_mb or settings.MAX_UPLOAD_SIZE_MB} MB)")

    # Content-Type soft check (clients lie; magic is source of truth)
    ct = (file.content_type or "").lower()
    if ct and ct not in (
        "application/octet-stream",
        "binary/octet-stream",
        "video/mp4",
        "video/quicktime",
        "video/webm",
        "video/x-matroska",
        "audio/mpeg",
        "audio/mp3",
        "audio/wav",
        "audio/x-wav",
        "audio/mp4",
        "audio/aac",
        "audio/ogg",
        "image/png",
        "image/jpeg",
        "image/webp",
    ):
        # Don't hard-fail on unknown CT if magic looks ok
        pass

    header = content[:64]
    if not _looks_like_media(header):
        raise HTTPException(400, "File content does not match a supported media format")

    # Sanitize filename stem – never trust client path components
    safe_stem = "".join(c for c in Path(file.filename).stem if c.isalnum() or c in "-_")[:80] or "upload"
    return ext, safe_stem


def safe_output_path(filename: str, base_dir: Path) -> Path:
    """Prevent path traversal when serving files from OUTPUT_DIR."""
    # Reject any path separators or parent refs before resolving
    if not filename or filename.strip() != filename:
        raise HTTPException(400, "Invalid filename")
    if "/" in filename or "\\" in filename or ".." in filename:
        raise HTTPException(400, "Invalid filename")
    name = Path(filename).name
    if not name or name.startswith(".") or name != filename:
        raise HTTPException(400, "Invalid filename")
    path = (base_dir / name).resolve()
    base = base_dir.resolve()
    try:
        path.relative_to(base)
    except ValueError:
        raise HTTPException(400, "Invalid path")
    return path

"""Text-to-Speech using edge-tts (free, high quality neural voices)."""
from __future__ import annotations

import logging
import re
import subprocess
from pathlib import Path
from typing import List, Optional

from app.core.config import settings
from app.models.schemas import TranscriptSegment

logger = logging.getLogger(__name__)


def _probe_duration(path: Path) -> float:
    try:
        r = subprocess.run(
            [
                "ffprobe", "-v", "error", "-show_entries", "format=duration",
                "-of", "default=noprint_wrappers=1:nokey=1", str(path),
            ],
            capture_output=True, text=True, timeout=30,
        )
        return float(r.stdout.strip() or "0")
    except Exception:
        return 0.0


def split_text_into_sentences(text: str) -> List[str]:
    sentences = re.split(r"(?<=[.!?])\s+", (text or "").strip())
    return [s.strip() for s in sentences if s.strip()]


def _proportional_segments(text: str, duration: float) -> List[TranscriptSegment]:
    """Build caption segments from sentences weighted by character length."""
    sentences = split_text_into_sentences(text)
    if not sentences:
        sentences = [text.strip() or "..."]
    weights = [max(len(s), 1) for s in sentences]
    total_w = sum(weights) or 1
    duration = max(duration, 0.5)
    segs: List[TranscriptSegment] = []
    t = 0.0
    for i, (s, w) in enumerate(zip(sentences, weights)):
        slot = duration * (w / total_w)
        end = duration if i == len(sentences) - 1 else min(duration, t + max(slot, 0.4))
        segs.append(TranscriptSegment(start=round(t, 3), end=round(end, 3), text=s))
        t = end
    return segs


async def generate_speech(
    text: str,
    output_path: Path,
    voice: str = "en-US-JennyNeural",
    rate: str = "+0%",
) -> Path:
    """Generate a single audio file from full text. Raises if empty output."""
    text = (text or "").strip()
    if len(text) < 2:
        raise ValueError("TTS text is empty")
    if len(text) > 15000:
        text = text[:15000]
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        import edge_tts
    except ImportError as e:
        raise RuntimeError("edge-tts is not installed. Run: pip install edge-tts") from e

    logger.info(f"Generating TTS voice={voice} chars={len(text)}")
    communicate = edge_tts.Communicate(text, voice, rate=rate)
    await communicate.save(str(output_path))

    if not output_path.exists() or output_path.stat().st_size < 200:
        raise RuntimeError("TTS produced empty or tiny audio file")
    logger.info(f"TTS saved {output_path} ({output_path.stat().st_size} bytes)")
    return output_path


async def generate_speech_with_timestamps(
    text: str,
    output_path: Path,
    voice: str = "en-US-JennyNeural",
) -> tuple[Path, List[TranscriptSegment]]:
    """
    Generate speech + timed segments.
    Prefer Whisper re-transcription of the TTS audio; fall back to proportional
    sentence timing so captions never go blank.
    """
    text = (text or "").strip()
    await generate_speech(text, output_path, voice)
    duration = _probe_duration(output_path)
    if duration <= 0:
        # estimate ~14 chars/sec spoken
        duration = max(len(text) / 14.0, 1.5)

    segments: List[TranscriptSegment] = []
    try:
        from app.services.transcription import transcribe_audio
        segments = transcribe_audio(output_path, word_timestamps=True)
    except Exception as e:
        logger.warning(f"Whisper align failed, using proportional captions: {e}")

    if not segments:
        segments = _proportional_segments(text, duration)

    # Ensure segments cover the audio and have non-empty text
    cleaned: List[TranscriptSegment] = []
    for s in segments:
        if not (s.text or "").strip():
            continue
        cleaned.append(s)
    if not cleaned:
        cleaned = _proportional_segments(text, duration)
    return Path(output_path), cleaned


async def list_available_voices(locale: str = "en") -> List[dict]:
    try:
        import edge_tts
        voices = await edge_tts.list_voices()
        return [
            {"name": v["ShortName"], "gender": v["Gender"], "locale": v["Locale"]}
            for v in voices
            if v["Locale"].startswith(locale)
        ]
    except Exception as e:
        logger.warning(f"list_voices failed: {e}")
        return [{"name": v, "gender": "Unknown", "locale": "en"} for v in settings.DEFAULT_VOICES]

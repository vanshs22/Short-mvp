#!/usr/bin/env bash
set -euo pipefail

echo "==> Installing system packages (ffmpeg)"
sudo apt-get update -qq
sudo apt-get install -y --no-install-recommends ffmpeg fonts-dejavu-core

echo "==> Installing yt-dlp (standalone binary, kept up to date independent of pip)"
sudo curl -fsSL https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp -o /usr/local/bin/yt-dlp
sudo chmod a+rx /usr/local/bin/yt-dlp

cd shorts-mvp

echo "==> Installing Python dependencies"
pip install --no-cache-dir -r requirements.txt

if [ ! -f .env ]; then
  echo "==> Creating .env from .env.example (edit before use)"
  cp .env.example .env
fi

mkdir -p uploads outputs backgrounds temp data assets

echo "==> Done. Run with: cd shorts-mvp && ./run.sh"

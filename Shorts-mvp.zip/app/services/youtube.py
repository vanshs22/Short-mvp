"""Download YouTube (and other yt-dlp sources) for reel extraction."""
from __future__ import annotations

import logging
import re
import subprocess
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse

logger = logging.getLogger(__name__)

# Basic allowlist of common hosts yt-dlp handles well for this product
ALLOWED_HOST_HINTS = (
    "youtube.com", "youtu.be", "www.youtube.com", "m.youtube.com",
    "youtube-nocookie.com",
)

YOUTUBE_URL_RE = re.compile(
    r"(https?://)?(www\.)?(youtube\.com|youtu\.be)/[\w\-?=&%.]+",
    re.I,
)


def is_youtube_url(url: str) -> bool:
    if not url or not url.strip():
        return False
    url = url.strip()
    if not YOUTUBE_URL_RE.search(url):
        # still allow if host looks like youtube
        try:
            host = urlparse(url if "://" in url else f"https://{url}").hostname or ""
            return any(h in host for h in ALLOWED_HOST_HINTS)
        except Exception:
            return False
    return True


def normalize_url(url: str) -> str:
    url = url.strip()
    if not url.startswith("http"):
        url = "https://" + url
    return url


def download_video(
    url: str,
    out_dir: Path,
    *,
    max_height: int = 1080,
    max_duration_sec: int = 1200,
) -> Path:
    """
    Download best video+audio muxed under max_height.
    Returns path to the downloaded media file.
    """
    from app.services.security import assert_safe_external_url
    if not is_youtube_url(url):
        raise ValueError("Only YouTube links are supported in this version")
    url = assert_safe_external_url(
        url,
        allow_hosts=("youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be", "youtube-nocookie.com", "www.youtube-nocookie.com"),
    )
    out_dir.mkdir(parents=True, exist_ok=True)
    out_tmpl = str(out_dir / "source.%(ext)s")

    # Prefer mp4 for FFmpeg compatibility
    fmt = f"bv*[height<=={max_height}][ext=mp4]+ba[ext=m4a]/b[height<=={max_height}][ext=mp4]/bv*[height<=={max_height}]+ba/b"
    cmd = [
        "yt-dlp",
        "--no-playlist",
        "--no-warnings",
        "-f", fmt,
        "--merge-output-format", "mp4",
        "--max-filesize", "500M",
        "-o", out_tmpl,
        "--print", "after_move:filepath",
        url,
    ]
    logger.info(f"yt-dlp download: {url}")
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
    if result.returncode != 0:
        err = (result.stderr or result.stdout or "")[-800:]
        logger.error(f"yt-dlp failed: {err}")
        raise RuntimeError(f"YouTube download failed: {err[:300]}")

    # Prefer printed path
    printed = (result.stdout or "").strip().splitlines()
    if printed:
        candidate = Path(printed[-1].strip())
        if candidate.exists():
            return candidate

    # Fallback: find newest file in out_dir
    files = sorted(out_dir.glob("source.*"), key=lambda p: p.stat().st_mtime, reverse=True)
    files = [f for f in files if f.suffix.lower() in {".mp4", ".mkv", ".webm", ".mov"}]
    if not files:
        raise RuntimeError("Download finished but no video file found")
    return files[0]


def probe_duration(path: Path) -> float:
    r = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "default=noprint_wrappers=1:nokey=1", str(path)],
        capture_output=True, text=True,
    )
    try:
        return float(r.stdout.strip())
    except Exception:
        return 0.0

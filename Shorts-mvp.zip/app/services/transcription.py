"""Transcription service using faster-whisper (word-level timestamps when available)."""
from pathlib import Path
from typing import List, Optional, Any
import logging

from app.core.config import settings
from app.models.schemas import TranscriptSegment

logger = logging.getLogger(__name__)

_model: Any = None


def get_whisper_model():
    global _model
    if _model is None:
        from faster_whisper import WhisperModel
        logger.info(f"Loading Whisper model: {settings.WHISPER_MODEL}")
        _model = WhisperModel(
            settings.WHISPER_MODEL,
            device=getattr(settings, "WHISPER_DEVICE", "cpu"),
            compute_type=getattr(settings, "WHISPER_COMPUTE", "int8"),
        )
        logger.info("Whisper model loaded")
    return _model


def transcribe_audio(audio_path: Path, word_timestamps: bool = True) -> List[TranscriptSegment]:
    """
    Transcribe an audio/video file and return timed segments.
    When word_timestamps=True, each segment may include a `words` list:
      [{"word": "...", "start": 0.1, "end": 0.3}, ...]
    """
    model = get_whisper_model()
    logger.info(f"Transcribing: {audio_path} (words={word_timestamps})")

    segments, info = model.transcribe(
        str(audio_path),
        beam_size=5,
        word_timestamps=word_timestamps,
        vad_filter=True,
    )

    result: List[TranscriptSegment] = []
    for seg in segments:
        text = seg.text.strip()
        if not text:
            continue
        words = None
        if word_timestamps and getattr(seg, "words", None):
            words = [
                {
                    "word": (w.word or "").strip(),
                    "start": round(float(w.start), 3),
                    "end": round(float(w.end), 3),
                }
                for w in seg.words
                if (w.word or "").strip()
            ]
        result.append(
            TranscriptSegment(
                start=round(seg.start, 3),
                end=round(seg.end, 3),
                text=text,
                words=words,
            )
        )

    logger.info(f"Transcription complete: {len(result)} segments, language={info.language}")
    return result


def segments_to_srt(segments: List[TranscriptSegment]) -> str:
    """Convert segments to SRT format."""
    lines = []
    for i, seg in enumerate(segments, 1):
        start = _format_timestamp(seg.start)
        end = _format_timestamp(seg.end)
        lines.append(f"{i}")
        lines.append(f"{start} --> {end}")
        lines.append(seg.text)
        lines.append("")
    return "\n".join(lines)


def segments_to_ass_karaoke(segments: List[TranscriptSegment], style_name: str = "karaoke") -> str:
    """
    Build an ASS subtitle file with per-word karaoke highlight (\\k tags).
    Falls back to plain timed lines when word timings are missing.
    """
    # ASS colours are &HAABBGGRR
    primary = "&H00FFFFFF"  # white
    secondary = "&H0000FFFF"  # yellow highlight (karaoke fill)
    outline = "&H00000000"
    if style_name == "neon":
        primary = "&H00CCFF00"
        secondary = "&H00FFFFFF"
    elif style_name == "bold_yellow":
        primary = "&H0000FFFF"
        secondary = "&H00FFFFFF"
    elif style_name == "bounce":
        primary = "&H00FFFFFF"
        secondary = "&H0000AAFF"
    elif style_name == "pop":
        primary = "&H0000EEFF"
        secondary = "&H00FFFFFF"

    header = f"""[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
WrapStyle: 0
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Arial Black,72,{primary},{secondary},{outline},&H80000000,-1,0,0,0,100,100,0,0,1,4,0,2,40,40,220,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    events = []
    for seg in segments:
        start = _ass_time(seg.start)
        end = _ass_time(seg.end)
        if seg.words and len(seg.words) > 0:
            parts = []
            for w in seg.words:
                dur_cs = max(1, int(round((w["end"] - w["start"]) * 100)))  # centiseconds
                # \k duration is in centiseconds; word highlighted as it plays
                safe = _ass_escape(w["word"])
                parts.append(rf"{{\k{dur_cs}}}{safe}")
            text = " ".join(parts)
        else:
            text = _ass_escape(seg.text)
        events.append(f"Dialogue: 0,{start},{end},Default,,0,0,0,,{text}")

    return header + "\n".join(events) + "\n"


def _ass_escape(text: str) -> str:
    return (
        text.replace("\\", r"\\")
        .replace("{", r"\{")
        .replace("}", r"\}")
        .replace("\n", " ")
    )


def _ass_time(seconds: float) -> str:
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = int(seconds % 60)
    cs = int(round((seconds % 1) * 100))
    if cs >= 100:
        cs = 99
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"


def _format_timestamp(seconds: float) -> str:
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = int(seconds % 60)
    ms = int((seconds % 1) * 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def _parse_srt_time(ts: str) -> float:
    """Parse SRT timestamp HH:MM:SS,mmm or HH:MM:SS.mmm → seconds."""
    ts = ts.strip().replace(",", ".")
    parts = ts.split(":")
    if len(parts) != 3:
        return 0.0
    h, m, s = parts
    return int(h) * 3600 + int(m) * 60 + float(s)


def parse_srt_text(text: str) -> List[TranscriptSegment]:
    """Parse SRT (or near-SRT) text into TranscriptSegment list."""
    import re
    blocks = re.split(r"\n\s*\n", text.strip())
    out: List[TranscriptSegment] = []
    for block in blocks:
        lines = [ln.strip() for ln in block.splitlines() if ln.strip()]
        if not lines:
            continue
        # Find timing line
        time_idx = None
        for i, ln in enumerate(lines):
            if "-->" in ln:
                time_idx = i
                break
        if time_idx is None:
            continue
        try:
            left, right = lines[time_idx].split("-->")
            start = _parse_srt_time(left)
            end = _parse_srt_time(right)
        except Exception:
            continue
        body = " ".join(lines[time_idx + 1 :]).strip()
        if body:
            out.append(TranscriptSegment(start=start, end=end, text=body))
    return out

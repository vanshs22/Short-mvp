import logging
from pathlib import Path


from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from slowapi import _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from app.core.limiter import limiter

from app.api.routes import router
from app.core.config import settings
from app.db.database import init_db

# Optional Sentry (set SENTRY_DSN in env)
if getattr(settings, "SENTRY_DSN", ""):
    try:
        import sentry_sdk
        from sentry_sdk.integrations.fastapi import FastApiIntegration
        from sentry_sdk.integrations.starlette import StarletteIntegration
        sentry_sdk.init(
            dsn=settings.SENTRY_DSN,
            integrations=[StarletteIntegration(), FastApiIntegration()],
            traces_sample_rate=0.1 if not settings.DEBUG else 0.0,
            environment=settings.DEPLOY_MODE,
            release=f"shorts-mvp@{settings.VERSION}",
        )
        logging.info("Sentry enabled")
    except Exception as e:
        logging.warning(f"Sentry init failed: {e}")


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)

app = FastAPI(
    title=settings.APP_NAME,
    description="Vertical shorts with viral templates – Phase 2/3/4",
    version=settings.VERSION,
)
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
    # API responses: no caching of sensitive data
    if request.url.path.startswith("/api/"):
        response.headers.setdefault("Cache-Control", "no-store")
    return response


# Restrict CORS in non-debug; keep permissive for local dev
_origins = ["*"] if settings.DEBUG else [
    "http://localhost:3000",
    "http://localhost:8000",
    "https://localhost",
]
app.add_middleware(
    CORSMiddleware,
    allow_origins=_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router, prefix="/api")
# Outputs served only via /api/outputs/{filename} (access-controlled)

FRONTEND_DIR = Path(__file__).resolve().parent.parent / "static"
FRONTEND_DIR.mkdir(exist_ok=True)
if FRONTEND_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(FRONTEND_DIR)), name="static")


@app.get("/")
async def root():
    index = FRONTEND_DIR / "index.html"
    if index.exists():
        return FileResponse(index)
    return {"message": "Shorts MVP API", "docs": "/docs", "version": settings.VERSION}


@app.get("/app.js")
async def serve_app_js():
    """Serve frontend bundle at root path expected by index.html."""
    p = FRONTEND_DIR / "app.js"
    if p.exists():
        return FileResponse(p, media_type="application/javascript")
    return JSONResponse({"detail": "app.js not found"}, status_code=404)


@app.get("/terms", response_class=HTMLResponse)
@app.get("/terms.html", response_class=HTMLResponse)
async def terms():
    p = FRONTEND_DIR / "terms.html"
    if p.exists():
        return FileResponse(p)
    return HTMLResponse("<h1>Terms of Service</h1><p>Placeholder. Replace before launch.</p>")


@app.get("/privacy", response_class=HTMLResponse)
@app.get("/privacy.html", response_class=HTMLResponse)
async def privacy():
    p = FRONTEND_DIR / "privacy.html"
    if p.exists():
        return FileResponse(p)
    return HTMLResponse("<h1>Privacy Policy</h1><p>Placeholder. Replace before launch.</p>")


@app.get("/content-policy", response_class=HTMLResponse)
@app.get("/content-policy.html", response_class=HTMLResponse)
async def content_policy():
    p = FRONTEND_DIR / "content-policy.html"
    if p.exists():
        return FileResponse(p)
    return HTMLResponse("<h1>Content Policy</h1><p>Placeholder.</p>")

@app.on_event("startup")
async def startup():
    init_db()
    try:
        from app.services.users import cleanup_expired_tokens
        n = cleanup_expired_tokens()
        if n:
            logging.info(f"Cleaned {n} expired session tokens")
    except Exception as e:
        logging.warning(f"Token cleanup skipped: {e}")
    logging.info(f"Starting {settings.APP_NAME} v{settings.VERSION}")
    logging.info(f"DB ready · Upload: {settings.UPLOAD_DIR}")

# Shorts MVP v0.5.0

Vertical shorts with viral templates. **Free-tier stack: Postgres + Redis + Resend.**

## Stack (free tiers)

| Service | Local | Cloud free |
|---------|-------|------------|
| **Postgres** | Docker `postgres:16` | [Neon](https://neon.tech) / Supabase |
| **Redis** | Docker `redis:7` | [Upstash](https://upstash.com) |
| **Email** | — | [Resend](https://resend.com) (API key) |
| **App** | FastAPI + Celery worker | Any small VPS / Railway / Render |
| **TTS/STT** | edge-tts + Whisper CPU | — |
| **Payments** | Stripe test / simulate | Stripe live when ready |

If Postgres or Redis is down, the app **falls back** to SQLite + BackgroundTasks automatically.

---

## Quick start (Docker – recommended)

```bash
cp backend/.env.example backend/.env
# Edit backend/.env → paste RESEND_API_KEY when you have it

docker compose up --build
```

- API: http://localhost:8000  
- Postgres: `localhost:5432` (user/pass/db: `shorts`)  
- Redis: `localhost:6379`  
- Worker: Celery consumer runs in the `worker` service  

---

## Quick start (local processes)

```bash
# Terminal 1 – infra
docker compose up postgres redis -d

# Terminal 2 – API
cd backend
cp .env.example .env   # set RESEND_API_KEY=
pip install -r requirements.txt
PYTHONPATH=. uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload

# Terminal 3 – worker
cd backend
PYTHONPATH=. celery -A app.workers.celery_app.celery_app worker -l info --concurrency=2
```

---

## Resend setup

1. Create account at resend.com  
2. Add and verify your domain (or use onboarding domain for tests)  
3. Create API key  
4. In `.env`:

```env
RESEND_API_KEY=re_xxxxxxxx
SMTP_FROM=noreply@yourdomain.com
```

Uses Resend’s HTTPS API. Alternatively set SMTP:

```env
SMTP_HOST=smtp.resend.com
SMTP_PORT=587
SMTP_USER=resend
SMTP_PASSWORD=re_xxxxxxxx
SMTP_FROM=noreply@yourdomain.com
```

Emails sent on: welcome, job complete, low credits.

---

## Neon Postgres (cloud free)

1. Create project on neon.tech  
2. Copy connection string  

```env
DATABASE_URL=postgresql://user:pass@ep-xxx.region.aws.neon.tech/shorts?sslmode=require
```

---

## Upstash Redis (cloud free)

```env
CELERY_BROKER_URL=rediss://default:PASSWORD@xxx.upstash.io:6379/0
CELERY_RESULT_BACKEND=rediss://default:PASSWORD@xxx.upstash.io:6379/1
```

---

## Env reference

See `backend/.env.example`. Important vars:

| Var | Purpose |
|-----|---------|
| `DATABASE_URL` | Postgres URL (fallback SQLite) |
| `CELERY_BROKER_URL` | Redis for jobs |
| `RESEND_API_KEY` | Transactional email |
| `STRIPE_*` | Payments (placeholder = simulate) |
| `STORAGE_BACKEND` | `local` or `s3` (R2 later) |

---

## Features

Templates: **Standard · Reddit · Fake Text · Split Screen**  

Auth · credits · Free/Pro/Studio · Stripe · dashboard · batch · tweaks · moderation · autoclip · metrics  

---

## Verify

```bash
curl localhost:8000/api/health
curl localhost:8000/api/metrics
# Expect: database=postgres, redis=true, queue=celery, email=resend (once key set)
```

---

## Later (when revenue)

- Cloudflare R2 for media (`STORAGE_BACKEND=s3`)  
- Stripe **live** keys  
- GPU Whisper (`WHISPER_DEVICE=cuda`, larger model)  
- Sentry DSN  

Until then: Postgres + Redis + Resend is enough and stays free.


---

## Tests (v0.5.0)

```bash
cd backend
pip install -r requirements.txt
PYTHONPATH=. pytest tests/ -v
```

27 tests cover: auth (register/login/logout/lockout), password policy, credits, moderation, health, rate limiting.

### Auth hardening
- bcrypt password hashes (legacy SHA256 auto-upgraded on login)
- Persistent session tokens in DB (7-day TTL)
- Logout + logout-all
- Account lockout after 8 failed logins (15 min)
- Password: min 8 chars, letter + number required
- Rate limits: auth 10/min, jobs 20/min, default 60/min (slowapi)
- Upload security: extension + magic-byte validation, path-traversal blocked
- Stripe: Price ID support, webhook idempotency, subscription cancel → free
- Scheduled-style cleanup via `POST /api/admin/cleanup` + `/api/ready`
- Backgrounds seeded (`backgrounds/solid_dark.mp4` + licensing README)


### v0.5.0 additions
- Real ToS + Privacy Policy drafts (`/terms`, `/privacy`) — replace contact emails before launch
- Sentry optional via `SENTRY_DSN`
- Word-level karaoke ASS captions (styles: karaoke, bounce, pop)
- `POST /api/jobs/{id}/cancel` + cancel-aware pipeline
- Finer job progress steps


---

## Production readiness (v0.5.0)

Completed from the hardening plan:

- Tests (46+) – auth, rate limit, upload security, Stripe sim, karaoke ASS, cancel/refund, legal pages
- Auth: bcrypt, DB sessions, lockout, logout
- Rate limits (slowapi)
- Upload validation + path traversal protection
- Stripe Price IDs + webhook idempotency
- Job cancel + credit refund + progress stages
- Word-level karaoke (ASS `\k` tags) for karaoke/bounce/pop styles
- Celery retries (transient errors, no retry on cancel)
- HTML email templates (Resend/SMTP)
- Sentry optional (`SENTRY_DSN`)
- Legal: Terms, Privacy, Content Policy
- Cleanup + `/api/ready`
- Backgrounds library + licensing notes

Still your responsibility before public traffic:

- Replace `support@example.com` / `privacy@example.com` / `dmca@example.com` with real addresses
- Have counsel review Terms/Privacy for your jurisdiction
- Set live Stripe keys + webhook endpoint
- Set `SENTRY_DSN` and `RESEND_API_KEY`
- Restrict CORS (`DEBUG=false`) and put HTTPS in front


---

## YouTube → Reels (v0.5.0)

New template tab **YouTube → Reels**:

1. Paste a YouTube URL
2. Choose max reels (1–10) and clip length range
3. App downloads with **yt-dlp**, finds energetic/non-silent moments, exports **vertical 9:16** clips
4. Optional captions burned from original audio

```bash
curl -X POST localhost:8000/api/jobs \
  -H "Authorization: Bearer $TOKEN" \
  -F template=youtube_reels \
  -F youtube_url='https://www.youtube.com/watch?v=...' \
  -F youtube_max_clips=5 \
  -F youtube_captions=true \
  -F caption_style=karaoke
```

Requires `yt-dlp` on the server (`pip install yt-dlp`). Credits: **1 per reel**.


---

## Security hardening (v0.5.0)

- bcrypt + session tokens + lockout + rate limits
- Job ownership checks on get / cancel / tweak
- Anonymous `/api/jobs` returns `[]` (no global leak)
- Outputs only via `/api/outputs/{uuid}` (no directory listing mount)
- Upload magic-byte + extension validation
- YouTube SSRF guard (blocks localhost/private IPs/file://)
- FFmpeg filter path escaping
- Security headers (nosniff, frame deny, referrer policy)
- Metrics require auth or `X-Admin-Token`
- Background upload requires auth
- Atomic credit consume (`SELECT … FOR UPDATE` when supported)


---

## v0.5.0 code polish

- All media URLs consistently `/api/outputs/...` (static mount removed for security)
- YouTube → Reels pipeline restored and verified in code path
- Background API no longer leaks absolute server paths
- Script max length enforced (15k)
- Tweak path prefers ASS for karaoke styles
- Low-credit email when ≤3 credits remain after a job
- `run.sh` creates dirs + .env from example
- 61 automated tests

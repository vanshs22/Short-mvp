# Shorts MVP v0.7.0

Production-oriented **vertical shorts factory**: AI script → voice → captions → 9:16 MP4, plus AI visual reels, YouTube multi-reels, and viral templates.

## What it does

| Feature | Description |
|---------|-------------|
| **AI script** | Topic + brief → spoken short-form script (OpenAI / OpenRouter / Groq or local) |
| **AI Visual Reels** | Script/topic → AI scene images → Ken Burns motion → TTS + captions |
| **Standard** | Script or upload → TTS + captions → vertical short |
| **Manual captions** | Paste plain lines or SRT to override auto captions |
| **Reddit / Fake text / Split / YouTube** | Viral format templates |
| **Auth + credits** | Free / Pro / Studio, Stripe hooks |
| **Jobs** | Queue, status, cancel, batch, tweaks |

## Quick start

```bash
cp backend/.env.example backend/.env
# LLM_API_KEY=sk-...   # or OpenRouter sk-or-v1-...
# LLM_BASE_URL=https://api.openai.com/v1
# LLM_MODEL=gpt-4o-mini
# IMAGE_MODEL=dall-e-3
# IMAGE_SIZE=1024x1792

cd backend
pip install -r requirements.txt
# need ffmpeg on PATH
./run.sh
```

Open http://localhost:8000

## Tests

```bash
cd backend && PYTHONPATH=. pytest tests/ -q
```

## License

MIT — replace legal contacts before public launch.

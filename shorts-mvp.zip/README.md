# Shorts MVP v0.6.0

Production-oriented vertical shorts factory: **AI script → voice → captions → 9:16 MP4**.

## What it does

| Feature | Description |
|---------|-------------|
| **AI script** | Topic + brief → spoken short-form script (LLM or local) |
| **Standard** | Script or upload → TTS + captions → vertical short |
| **Reddit** | Story card + narration + captions |
| **Fake text** | iMessage/WhatsApp-style chat short |
| **Split screen** | Streamer-style layout |
| **YouTube → Reels** | URL → highlights → multiple 9:16 reels |
| **Auth + credits** | Free / Pro / Studio, Stripe hooks |
| **Jobs** | Queue, status, cancel, batch, tweaks |

## Stack

- FastAPI + Celery + Redis + Postgres (SQLite fallback)
- edge-tts + faster-whisper + FFmpeg + yt-dlp
- Resend email, Stripe billing, optional Sentry / LLM

## Quick start (Docker)

```bash
cp backend/.env.example backend/.env
# optional: RESEND_API_KEY, LLM_API_KEY, STRIPE_*
docker compose up --build
```

→ http://localhost:8000

## Local

```bash
# need: ffmpeg, yt-dlp
cd backend
cp .env.example .env
pip install -r requirements.txt
./run.sh
```

## Tests

```bash
cd backend
PYTHONPATH=. pytest tests/ -q
```

## Env highlights

| Variable | Purpose |
|----------|---------|
| `DATABASE_URL` | Postgres (else SQLite) |
| `CELERY_BROKER_URL` | Redis |
| `RESEND_API_KEY` | Email |
| `LLM_API_KEY` + `LLM_BASE_URL` | AI scripts (optional) |
| `STRIPE_*` | Payments |
| `ADMIN_API_TOKEN` | Metrics protection |
| `DEBUG=false` | Production CORS |

## License

MIT — use at your own risk. Replace legal page contacts before public launch.

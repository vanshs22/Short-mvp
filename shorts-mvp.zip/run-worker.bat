@echo off
setlocal
cd /d "%~dp0"
set PYTHONPATH=.

if not exist uploads mkdir uploads
if not exist outputs mkdir outputs
if not exist backgrounds mkdir backgrounds
if not exist temp mkdir temp
if not exist data mkdir data
if not exist assets mkdir assets

if not exist .env (
  if exist .env.example copy /Y .env.example .env >nul
)

where python >nul 2>&1
if %errorlevel%==0 (
  set PYBIN=python
) else (
  set PYBIN=py
)

if "%SKIP_DEP_INSTALL%"=="1" (
  echo Skipping dependency install ^(SKIP_DEP_INSTALL=1^)
) else (
  %PYBIN% -m pip install -q -r requirements.txt
  %PYBIN% -m pip install -q -U yt-dlp
)

if "%CELERY_CONCURRENCY%"=="" set CELERY_CONCURRENCY=2
echo Starting Celery worker (concurrency=%CELERY_CONCURRENCY%)
rem Windows has no fork(), so Celery's default "prefork" pool crashes here —
rem "solo" is the pool that actually works on native Windows Python.
%PYBIN% -m celery -A app.workers.celery_app.celery_app worker -l info --pool=solo --concurrency=%CELERY_CONCURRENCY%

"""Postgres preferred; falls back to SQLite if DATABASE_URL unreachable or empty."""
from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path

from sqlalchemy import (
    create_engine, Column, String, Integer, Float, DateTime, Text, ForeignKey, text, Boolean
)
from sqlalchemy.orm import sessionmaker, declarative_base

from app.core.config import settings

logger = logging.getLogger(__name__)


def _make_engine():
    url = (settings.DATABASE_URL or "").strip()
    if url and url.startswith("postgres"):
        try:
            eng = create_engine(url, pool_pre_ping=True, pool_size=5, max_overflow=10)
            with eng.connect() as conn:
                conn.execute(text("SELECT 1"))
            logger.info(f"Using Postgres: {url.split('@')[-1] if '@' in url else 'configured'}")
            return eng
        except Exception as e:
            logger.warning(f"Postgres unavailable ({e}); falling back to SQLite")
    # Use project-local SQLite for tests / offline
    db_path = Path(settings.BASE_DIR) / "data" / "shorts.db"
    db_path.parent.mkdir(parents=True, exist_ok=True)
    logger.info(f"Using SQLite: {db_path}")
    return create_engine(f"sqlite:///{db_path}", connect_args={"check_same_thread": False})


engine = _make_engine()
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


class UserRow(Base):
    __tablename__ = "users"
    id = Column(String, primary_key=True)
    email = Column(String, unique=True, index=True, nullable=False)
    name = Column(String, nullable=True)
    password_hash = Column(String, nullable=False)
    salt = Column(String, nullable=False)
    plan = Column(String, default="free")
    credits_remaining = Column(Integer, default=20)
    videos_this_week = Column(Integer, default=0)
    week_start = Column(DateTime, default=datetime.utcnow)
    stripe_customer_id = Column(String, nullable=True)
    stripe_subscription_id = Column(String, nullable=True)
    storage_used_bytes = Column(Integer, default=0)
    is_active = Column(Boolean, default=True)
    failed_login_attempts = Column(Integer, default=0)
    locked_until = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class SessionToken(Base):
    """Persistent session tokens with expiry (survives restarts)."""
    __tablename__ = "session_tokens"
    token = Column(String, primary_key=True)
    user_id = Column(String, ForeignKey("users.id"), index=True, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime, nullable=False)
    last_used_at = Column(DateTime, default=datetime.utcnow)
    user_agent = Column(String, nullable=True)
    ip = Column(String, nullable=True)


class JobRow(Base):
    __tablename__ = "jobs"
    id = Column(String, primary_key=True)
    user_id = Column(String, ForeignKey("users.id"), nullable=True, index=True)
    status = Column(String, default="pending")
    progress = Column(Float, default=0.0)
    message = Column(String, default="")
    error = Column(Text, nullable=True)
    input_type = Column(String, default="script")
    template = Column(String, default="standard")
    caption_style = Column(String, default="classic")
    voice = Column(String, default="en-US-JennyNeural")
    output_url = Column(String, nullable=True)
    output_path = Column(String, nullable=True)
    output_bytes = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)


class CreditLedger(Base):
    __tablename__ = "credit_ledger"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(String, index=True, nullable=False)
    delta = Column(Integer, nullable=False)
    reason = Column(String, default="")
    stripe_payment_id = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


def init_db():
    Base.metadata.create_all(bind=engine)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

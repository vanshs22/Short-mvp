"""Celery application – run: celery -A app.workers.celery_app.celery_app worker -l info"""
from __future__ import annotations

import asyncio
import logging

from celery import Celery

from app.core.config import settings

logger = logging.getLogger(__name__)

broker = settings.CELERY_BROKER_URL or "redis://localhost:6379/0"
backend = settings.CELERY_RESULT_BACKEND or "redis://localhost:6379/1"

celery_app = Celery("shorts", broker=broker, backend=backend)
celery_app.conf.update(
    task_serializer="json",
    result_serializer="json",
    accept_content=["json"],
    task_track_started=True,
    task_time_limit=settings.JOB_TIMEOUT_SECONDS,
    task_soft_time_limit=max(30, settings.JOB_TIMEOUT_SECONDS - 30),
    worker_prefetch_multiplier=1,
    task_acks_late=True,
    task_reject_on_worker_lost=True,
    # Dead-letter style: keep failed results for inspection
    result_expires=86400 * 7,
)


@celery_app.task(
    name="shorts.run_pipeline",
    bind=True,
    max_retries=2,
    default_retry_delay=15,
    autoretry_for=(ConnectionError, TimeoutError, OSError),
)
def run_pipeline_task(self, job_id: str, request_data: dict, upload_path: str | None = None):
    """Serialize CreateJobRequest as dict for the worker. Retries transient failures."""
    from pathlib import Path
    from app.models.schemas import CreateJobRequest
    from app.services.pipeline import run_pipeline

    request = CreateJobRequest(**request_data)
    path = Path(upload_path) if upload_path else None

    async def _run():
        await run_pipeline(job_id, request, path)

    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            loop.run_until_complete(_run())
        finally:
            loop.close()
        return {"job_id": job_id, "status": "ok"}
    except RuntimeError as e:
        # User cancel – do not retry
        if "cancelled" in str(e).lower():
            logger.info(f"Celery job {job_id} cancelled – not retrying")
            return {"job_id": job_id, "status": "cancelled"}
        logger.exception(f"Celery job {job_id} failed")
        raise
    except Exception as e:
        logger.exception(f"Celery job {job_id} failed (attempt {self.request.retries + 1})")
        if self.request.retries < self.max_retries:
            raise self.retry(exc=e, countdown=15 * (self.request.retries + 1))
        raise

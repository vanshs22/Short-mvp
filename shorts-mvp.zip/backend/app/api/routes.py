import json
import logging
import uuid
from pathlib import Path
from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, BackgroundTasks, Depends, File, Form, Header, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse
from app.core.limiter import limiter

from app.core.config import settings
from app.models.schemas import (
    CreateJobRequest, JobResponse, CaptionStyle, VoiceOption, TemplateType,
    HealthResponse, BackgroundInfo, UserCreate, UserLogin, UserResponse,
    UsageLimits, BatchJobRequest, RedditStoryRequest, FakeTextRequest,
    FakeTextMessage, FakeTextPlatform, SplitScreenRequest, YoutubeReelsRequest, TweakRequest,
    CheckoutRequest, CheckoutResponse, ScriptGenerateRequest, ScriptGenerateResponse,
    AiVisualRequest,
)
from app.services.pipeline import create_job, get_job, list_jobs, run_pipeline, apply_tweaks, cancel_job
from app.services.queue import enqueue_pipeline
from app.services import users as user_service
from app.services.billing import stripe_service

logger = logging.getLogger(__name__)
router = APIRouter()


def _optional_user(authorization: Optional[str] = Header(None)) -> Optional[UserResponse]:
    if not authorization:
        return None
    token = authorization.replace("Bearer ", "").strip()
    return user_service.get_user_by_token(token)


def _require_user(authorization: Optional[str] = Header(None)) -> UserResponse:
    user = _optional_user(authorization)
    if not user:
        raise HTTPException(401, "Authentication required")
    return user


def _require_admin(
    authorization: Optional[str] = Header(None),
    x_admin_token: Optional[str] = Header(None, alias="X-Admin-Token"),
) -> UserResponse:
    """Admin if X-Admin-Token matches settings, or authenticated studio plan user."""
    if settings.ADMIN_API_TOKEN and x_admin_token and x_admin_token == settings.ADMIN_API_TOKEN:
        # synthetic admin for ops
        from app.models.schemas import UserResponse
        from datetime import datetime
        return UserResponse(
            id="admin", email="admin@local", name="Admin", plan="studio",
            credits_remaining=0, videos_this_week=0, created_at=datetime.utcnow(),
        )
    user = _require_user(authorization)
    if user.plan != "studio" and not (settings.ADMIN_API_TOKEN and x_admin_token == settings.ADMIN_API_TOKEN):
        # allow studio plan as soft-admin for cleanup of own data only handled elsewhere
        pass
    return user


@router.get("/health", response_model=HealthResponse)
async def health():
    from app.services.image_gen import image_gen_available
    from app.services.queue import redis_available
    redis_ok = redis_available()
    return HealthResponse(
        status="ok",
        version=settings.VERSION,
        deploy_mode=getattr(settings, "DEPLOY_MODE", "bootstrap"),
        whisper_model=settings.WHISPER_MODEL,
        available_voices=[v.value for v in VoiceOption],
        available_styles=[s.value for s in CaptionStyle],
        available_templates=[t.value for t in TemplateType],
        image_gen_enabled=image_gen_available(),
        llm_configured=bool(settings.LLM_API_KEY),
        redis_available=redis_ok,
        queue_backend="celery" if redis_ok else "background",
    )


# ---------- Auth ----------
@router.post("/auth/register", response_model=UserResponse)
@limiter.limit(settings.RATE_LIMIT_AUTH)
async def register(request: Request, body: UserCreate):
    try:
        user = user_service.create_user(body.email, body.password, body.name)
        try:
            from app.services.email_service import notify_welcome
            from app.services import analytics as analytics_service
            notify_welcome(user.email, user.name)
            analytics_service.track("user_registered", user.id, plan=user.plan)
        except Exception:
            pass
        return user
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.post("/auth/login")
@limiter.limit(settings.RATE_LIMIT_AUTH)
async def login(request: Request, body: UserLogin):
    try:
        ip = request.client.host if request.client else None
        ua = request.headers.get("user-agent")
        user, token = user_service.authenticate(
            body.email, body.password, ip=ip, user_agent=ua
        )
        return {"user": user, "token": token, "expires_in_days": getattr(settings, "TOKEN_TTL_DAYS", 7)}
    except ValueError as e:
        raise HTTPException(401, str(e))


@router.post("/auth/logout")
async def logout(authorization: Optional[str] = Header(None)):
    if not authorization:
        return {"ok": True}
    token = authorization.replace("Bearer ", "").strip()
    user_service.logout(token)
    return {"ok": True}


@router.post("/auth/logout-all")
async def logout_all(user: UserResponse = Depends(_require_user)):
    n = user_service.logout_all(user.id)
    return {"ok": True, "revoked": n}


@router.get("/auth/me", response_model=UserResponse)
async def me(user: UserResponse = Depends(_require_user)):
    return user


@router.get("/usage", response_model=UsageLimits)
async def usage(user: Optional[UserResponse] = Depends(_optional_user)):
    return user_service.usage_limits(user.id if user else "")


@router.get("/dashboard")
async def dashboard(user: UserResponse = Depends(_require_user)):
    return user_service.dashboard_stats(user.id)


# ---------- Billing (Phase 3) ----------
@router.get("/billing/plans")
async def list_plans():
    from app.services.billing.plans import plan_catalog
    from app.services.billing import crypto_service, stripe_service
    cat = plan_catalog()
    stripe_ok = stripe_service._is_configured()
    crypto_ok = crypto_service.crypto_configured()
    return {
        **cat,
        "stripe_configured": stripe_ok,
        "crypto_configured": crypto_ok,
        "payment_mode": "live" if (stripe_ok or crypto_ok) else "simulate",
        "simulate_allowed": getattr(settings, "ALLOW_PAYMENT_SIMULATE", False),
        "providers": ["stripe", "crypto"],
    }


@router.post("/billing/checkout", response_model=CheckoutResponse)
async def checkout(body: CheckoutRequest, user: UserResponse = Depends(_require_user)):
    """Stripe or crypto. Real charges when keys are set; simulate only if not configured
    and ALLOW_PAYMENT_SIMULATE is enabled (dev).
    """
    provider = (getattr(body, "provider", None) or "stripe").lower()
    try:
        if provider == "crypto":
            from app.services.billing import crypto_service
            result = crypto_service.create_crypto_invoice(user.id, user.email, body.kind)
        else:
            result = stripe_service.create_checkout_session(user.id, user.email, body.kind)
        return CheckoutResponse(
            checkout_url=result["checkout_url"],
            session_id=result["session_id"],
        )
    except ValueError as e:
        raise HTTPException(400, str(e))
    except RuntimeError as e:
        # Missing keys without simulate, or provider misconfiguration
        raise HTTPException(503, str(e))
    except Exception as e:
        logger.exception("Checkout failed")
        raise HTTPException(502, f"Payment provider error: {str(e)[:200]}")


@router.post("/billing/crypto/webhook")
async def crypto_webhook(request: Request):
    from app.services.billing import crypto_service
    try:
        body = await request.json()
    except Exception:
        raise HTTPException(400, "Invalid JSON")
    sig = request.headers.get("x-nowpayments-sig") or request.headers.get("x-signature")
    ok = crypto_service.handle_ipn(body, signature=sig)
    return {"ok": ok}


@router.get("/billing/crypto/status/{payment_id}")
async def crypto_status(payment_id: str, user: UserResponse = Depends(_require_user)):
    from app.services.billing import crypto_service
    p = crypto_service.get_payment(payment_id)
    if not p:
        raise HTTPException(404, "Payment not found")
    return p


@router.get("/auth/sessions")
async def my_sessions(user: UserResponse = Depends(_require_user)):
    return {"sessions": user_service.list_sessions(user.id)}


@router.post("/billing/webhook")
async def stripe_webhook(request: Request):
    payload = await request.body()
    sig = request.headers.get("stripe-signature", "")
    try:
        result = stripe_service.handle_webhook_event(payload, sig)
        return result
    except Exception as e:
        raise HTTPException(400, str(e))



@router.post("/generate-script", response_model=ScriptGenerateResponse)
@limiter.limit(settings.RATE_LIMIT_JOBS)
async def generate_script_endpoint(
    request: Request,
    body: ScriptGenerateRequest,
    user: Optional[UserResponse] = Depends(_optional_user),
):
    """Generate a short-form spoken script from topic + brief (LLM or local template)."""
    from app.services.script_gen import generate_script
    from app.services.moderation import check_text

    combined = f"{body.topic}\n{body.brief}"
    reason = check_text(combined)
    if reason:
        raise HTTPException(400, f"Content blocked: {reason}")
    try:
        result = await generate_script(
            body.topic,
            body.brief,
            tone=body.tone,
            length=body.length,
            language=body.language,
        )
    except ValueError as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        raise HTTPException(502, f"Script generation failed: {str(e)[:200]}")
    return ScriptGenerateResponse(**result)


# ---------- Jobs ----------
@router.post("/jobs", response_model=JobResponse)
@limiter.limit(settings.RATE_LIMIT_JOBS)
async def create_job_endpoint(
    request: Request,
    background_tasks: BackgroundTasks,
    template: str = Form("standard"),
    script: Optional[str] = Form(None),
    caption_style: str = Form("classic"),
    voice: str = Form("en-US-JennyNeural"),
    background_id: Optional[str] = Form(None),
    burn_captions: bool = Form(True),
    reddit_title: Optional[str] = Form(None),
    reddit_body: Optional[str] = Form(None),
    reddit_subreddit: str = Form("r/AmItheAsshole"),
    reddit_username: str = Form("u/Anonymous"),
    reddit_upvotes: str = Form("12.4k"),
    fake_text_json: Optional[str] = Form(None),
    fake_contact: str = Form("Alex"),
    fake_platform: str = Form("imessage"),
    fake_narrate: bool = Form(True),
    split_label: str = Form("Streamer"),
    split_layout: str = Form("top_bottom"),
    youtube_url: Optional[str] = Form(None),
    youtube_max_clips: int = Form(5),
    youtube_min_sec: float = Form(12.0),
    youtube_max_sec: float = Form(45.0),
    youtube_captions: bool = Form(True),
    manual_captions: Optional[str] = Form(None),
    ai_topic: Optional[str] = Form(None),
    ai_max_scenes: int = Form(4),
    ai_image_style: str = Form("cinematic"),
    file: Optional[UploadFile] = File(None),
    user: Optional[UserResponse] = Depends(_optional_user),
):
    # Credit cost: youtube multi-clip and ai_visual cost more
    credit_cost = 1
    try:
        if template == "youtube_reels":
            credit_cost = max(1, int(youtube_max_clips or 1))
        elif template == "ai_visual":
            credit_cost = max(1, int(getattr(settings, "AI_VISUAL_CREDIT_COST", 2)))
    except Exception:
        credit_cost = 1
    if user:
        ok, reason = user_service.can_start_job(user.id)
        if not ok:
            raise HTTPException(429, reason)
        if not user_service.check_and_consume_credit(user.id, cost=credit_cost):
            raise HTTPException(402, "Out of credits or weekly limit. Upgrade or buy a pack.")
        try:
            lim = user_service.usage_limits(user.id)
            if lim.credits_remaining <= 3:
                from app.services.email_service import notify_low_credits
                u = user_service.get_user(user.id)
                if u:
                    notify_low_credits(u.email, lim.credits_remaining)
        except Exception:
            pass

    try:
        tmpl = TemplateType(template)
    except ValueError:
        tmpl = TemplateType.STANDARD
    try:
        style = CaptionStyle(caption_style)
    except ValueError:
        style = CaptionStyle.CLASSIC
    try:
        voice_opt = VoiceOption(voice)
    except ValueError:
        voice_opt = VoiceOption.JENNY

    reddit = None
    if tmpl == TemplateType.REDDIT_STORY:
        if not reddit_title or not reddit_body:
            raise HTTPException(400, "reddit_title and reddit_body required")
        reddit = RedditStoryRequest(
            title=reddit_title, body=reddit_body, subreddit=reddit_subreddit,
            username=reddit_username, upvotes=reddit_upvotes,
        )

    fake_text = None
    if tmpl == TemplateType.FAKE_TEXT:
        if not fake_text_json:
            raise HTTPException(400, "fake_text_json required")
        try:
            raw = json.loads(fake_text_json)
            messages = [FakeTextMessage(**m) for m in raw]
        except Exception as e:
            raise HTTPException(400, f"Invalid fake_text_json: {e}")
        try:
            platform = FakeTextPlatform(fake_platform)
        except ValueError:
            platform = FakeTextPlatform.IMESSAGE
        fake_text = FakeTextRequest(
            platform=platform, contact_name=fake_contact, messages=messages, narrate=fake_narrate,
        )

    split_screen = None
    if tmpl == TemplateType.SPLIT_SCREEN:
        split_screen = SplitScreenRequest(top_label=split_label, layout=split_layout)
        if not script:
            raise HTTPException(400, "script required for split_screen")

    youtube = None
    if tmpl == TemplateType.YOUTUBE_REELS:
        if not youtube_url:
            raise HTTPException(400, "youtube_url required for youtube_reels template")
        youtube = YoutubeReelsRequest(
            url=youtube_url.strip(),
            max_clips=max(1, min(10, youtube_max_clips)),
            min_clip_sec=youtube_min_sec,
            max_clip_sec=youtube_max_sec,
            burn_captions=youtube_captions,
        )

    if script and len(script) > 15000:
        raise HTTPException(400, "Script too long (max 15000 characters)")
    if tmpl == TemplateType.STANDARD and not script and not file:
        raise HTTPException(400, "Provide script or file for standard template")
    if tmpl == TemplateType.YOUTUBE_REELS and not youtube:
        raise HTTPException(400, "youtube_url required")

    ai_visual = None
    if tmpl == TemplateType.AI_VISUAL:
        if not script and not ai_topic:
            raise HTTPException(400, "ai_visual needs script or ai_topic")
        ai_visual = AiVisualRequest(
            topic=ai_topic,
            max_scenes=max(2, min(8, int(ai_max_scenes or 4))),
            image_style=ai_image_style or "cinematic",
        )

    request = CreateJobRequest(
        template=tmpl, script=script, caption_style=style, voice=voice_opt,
        background_id=background_id, burn_captions=burn_captions,
        manual_captions=manual_captions,
        reddit=reddit, fake_text=fake_text, split_screen=split_screen, youtube=youtube,
        ai_visual=ai_visual,
    )

    upload_path = None
    input_type = "script"
    if file and file.filename:
        input_type = "upload"
        content = await file.read()
        from app.services.upload_security import validate_upload, ALLOWED_UPLOAD_EXTS
        ext, safe_stem = validate_upload(file, content, allowed_exts=ALLOWED_UPLOAD_EXTS)
        job_tmp = settings.UPLOAD_DIR / f"{uuid.uuid4()}_{safe_stem}{ext}"
        job_tmp.write_bytes(content)
        upload_path = job_tmp

    # Content moderation
    if settings.ENABLE_MODERATION:
        from app.services.moderation import check_job_payload
        msgs = None
        if fake_text:
            msgs = [{"text": m.text} for m in fake_text.messages]
        reason = check_job_payload(script, reddit_body if reddit else None, msgs)
        if reason:
            raise HTTPException(400, reason)

    # Storage soft-check
    if user and not user_service.can_store(user.id, additional_bytes=50_000_000):
        raise HTTPException(402, "Storage quota exceeded. Delete old jobs or upgrade.")

    from app.services import analytics as analytics_service
    analytics_service.track("job_created", user.id if user else None, template=str(tmpl))

    if tmpl == TemplateType.YOUTUBE_REELS:
        input_type = "youtube"
    elif tmpl == TemplateType.AI_VISUAL:
        input_type = "ai_visual"
    job = create_job(request, upload_path, input_type=input_type, user_id=user.id if user else None)
    enqueue_pipeline(background_tasks, job.id, request, upload_path)
    return job


@router.post("/jobs/batch", response_model=List[JobResponse])
async def create_batch(
    body: BatchJobRequest,
    background_tasks: BackgroundTasks,
    user: Optional[UserResponse] = Depends(_optional_user),
):
    limits = user_service.usage_limits(user.id if user else "")
    if len(body.jobs) > limits.max_batch_size:
        raise HTTPException(400, f"Batch size max is {limits.max_batch_size} on your plan")
    results = []
    for req in body.jobs:
        if user and not user_service.check_and_consume_credit(user.id, cost=1):
            break
        job = create_job(req, user_id=user.id if user else None)
        enqueue_pipeline(background_tasks, job.id, req, None)
        results.append(job)
    return results


@router.post("/jobs/{job_id}/tweak", response_model=JobResponse)
async def tweak_job(job_id: str, body: TweakRequest, user: Optional[UserResponse] = Depends(_optional_user)):
    job = get_job(job_id)
    if not job:
        raise HTTPException(404, "Job not found")
    from app.services.security import assert_job_access
    assert_job_access(job, user, write=True)
    try:
        return apply_tweaks(job_id, body)
    except ValueError as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        raise HTTPException(500, str(e)[:200])


@router.get("/jobs", response_model=List[JobResponse])
async def list_jobs_endpoint(limit: int = 20, user: Optional[UserResponse] = Depends(_optional_user)):
    if not user:
        return []  # never leak other users' jobs to anonymous clients
    limit = max(1, min(50, limit))
    return list_jobs(limit, user_id=user.id)


@router.get("/jobs/{job_id}", response_model=JobResponse)
async def get_job_endpoint(job_id: str, user: Optional[UserResponse] = Depends(_optional_user)):
    job = get_job(job_id)
    if not job:
        raise HTTPException(404, "Job not found")
    from app.services.security import assert_job_access
    assert_job_access(job, user, write=False)
    return job


@router.post("/jobs/{job_id}/cancel", response_model=JobResponse)
async def cancel_job_endpoint(job_id: str, user: Optional[UserResponse] = Depends(_optional_user)):
    try:
        return cancel_job(job_id, user_id=user.id if user else None)
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.get("/outputs/{filename}")
async def serve_output(filename: str, user: Optional[UserResponse] = Depends(_optional_user)):
    """
    Serve generated media. Filenames are unguessable UUIDs (capability URLs).
    Path traversal is blocked; only files under OUTPUT_DIR are served.
    """
    from app.services.upload_security import safe_output_path
    path = safe_output_path(filename, settings.OUTPUT_DIR)
    if not path.exists() or not path.is_file():
        raise HTTPException(404, "File not found")
    # Only allow media extensions
    if path.suffix.lower() not in {".mp4", ".webm", ".mov", ".png", ".jpg", ".jpeg", ".wav", ".mp3"}:
        raise HTTPException(400, "Unsupported file type")
    media = {
        ".mp4": "video/mp4", ".webm": "video/webm", ".mov": "video/quicktime",
        ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
        ".wav": "audio/wav", ".mp3": "audio/mpeg",
    }.get(path.suffix.lower(), "application/octet-stream")
    return FileResponse(
        path,
        media_type=media,
        filename=path.name,
        headers={"Content-Disposition": f'inline; filename="{path.name}"', "X-Content-Type-Options": "nosniff"},
    )


@router.get("/backgrounds", response_model=List[BackgroundInfo])
async def list_backgrounds():
    items = []
    for p in settings.BACKGROUND_DIR.glob("*"):
        if p.suffix.lower() in {".mp4", ".mov", ".webm", ".mkv"}:
            items.append(BackgroundInfo(id=p.name, name=p.stem, path=p.name))
    return items


@router.post("/backgrounds")
async def upload_background(file: UploadFile = File(...), user: UserResponse = Depends(_require_user)):
    content = await file.read()
    from app.services.upload_security import validate_upload, ALLOWED_BACKGROUND_EXTS
    ext, safe_stem = validate_upload(file, content, allowed_exts=ALLOWED_BACKGROUND_EXTS)
    dest = settings.BACKGROUND_DIR / f"{safe_stem}{ext}"
    # avoid overwrite collisions
    if dest.exists():
        dest = settings.BACKGROUND_DIR / f"{safe_stem}_{uuid.uuid4().hex[:6]}{ext}"
    dest.write_bytes(content)
    return BackgroundInfo(id=dest.name, name=dest.stem, path=dest.name)


# ---------- Phase 4: Auto-clip, metrics, analytics, cleanup ----------

@router.post("/autoclip")
async def autoclip_video(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    max_clips: int = Form(3),
    user: Optional[UserResponse] = Depends(_optional_user),
):
    """Detect highlight segments from a long video and return clip ranges (+ optional extract)."""
    from app.services.autoclip import detect_highlights, extract_clip
    from app.services import analytics as analytics_service

    if user and not user_service.check_and_consume_credit(user.id, cost=1):
        raise HTTPException(402, "Out of credits")

    content = await file.read()
    from app.services.upload_security import validate_upload, ALLOWED_UPLOAD_EXTS
    ext, safe_stem = validate_upload(file, content, allowed_exts=ALLOWED_UPLOAD_EXTS)
    src = settings.UPLOAD_DIR / f"autoclip_{uuid.uuid4().hex}_{safe_stem}{ext}"
    src.write_bytes(content)

    clips = detect_highlights(src, max_clips=min(max_clips, settings.MAX_AUTOCLIPS))
    analytics_service.track("autoclip", user.id if user else None, clips=len(clips))

    # Extract first clip as sample output
    sample_path = None
    if clips:
        out = settings.OUTPUT_DIR / f"autoclip_{uuid.uuid4().hex[:8]}.mp4"
        try:
            extract_clip(src, clips[0][0], clips[0][1], out)
            sample_path = f"/api/outputs/{out.name}"
        except Exception as e:
            logger.warning(f"Sample extract failed: {e}")

    return {
        "clips": [{"start": s, "end": e, "duration": round(e - s, 2)} for s, e in clips],
        "sample_url": sample_path,
        "source": src.name,
    }


@router.post("/effects/remove-bg")
async def remove_bg(file: UploadFile = File(...), user: Optional[UserResponse] = Depends(_optional_user)):
    from app.services.effects import rembg_available, remove_background_image
    if not rembg_available():
        raise HTTPException(501, "rembg not available on this server")
    if user and not user_service.check_and_consume_credit(user.id, cost=1):
        raise HTTPException(402, "Out of credits")
    content = await file.read()
    from app.services.upload_security import validate_upload, IMAGE_EXTS
    ext, safe_stem = validate_upload(file, content, allowed_exts=IMAGE_EXTS, max_mb=20)
    src = settings.TEMP_DIR / f"bg_{uuid.uuid4().hex}_{safe_stem}{ext}"
    out = settings.OUTPUT_DIR / f"nobg_{uuid.uuid4().hex[:8]}.png"
    src.write_bytes(content)
    remove_background_image(src, out)
    return {"url": f"/api/outputs/{out.name}"}


@router.get("/metrics")
async def metrics(
    authorization: Optional[str] = Header(None),
    x_admin_token: Optional[str] = Header(None, alias="X-Admin-Token"),
):
    """Ops metrics – requires login or X-Admin-Token when ADMIN_API_TOKEN is set."""
    if settings.ADMIN_API_TOKEN:
        if x_admin_token != settings.ADMIN_API_TOKEN:
            user = _optional_user(authorization)
            if not user:
                raise HTTPException(401, "Admin token or auth required")
    else:
        # no admin token configured: still require some auth to avoid public leak
        user = _optional_user(authorization)
        if not user:
            raise HTTPException(401, "Authentication required")
    from app.services import analytics as analytics_service
    from app.db.database import SessionLocal, JobRow, UserRow
    db = SessionLocal()
    try:
        jobs = db.query(JobRow).count()
        users = db.query(UserRow).count()
        completed = db.query(JobRow).filter(JobRow.status == "completed").count()
        failed = db.query(JobRow).filter(JobRow.status == "failed").count()
    finally:
        db.close()
    from app.services.queue import redis_available
    db_kind = "postgres" if (settings.DATABASE_URL or "").startswith("postgres") else "sqlite"
    return {
        "version": settings.VERSION,
        "deploy_mode": getattr(settings, "DEPLOY_MODE", "growth"),
        "users": users,
        "jobs_total": jobs,
        "jobs_completed": completed,
        "jobs_failed": failed,
        "analytics": analytics_service.summary(),
        "queue": "celery" if redis_available() else "background_tasks",
        "redis": redis_available(),
        "database": db_kind,
        "email": "resend" if settings.RESEND_API_KEY else ("smtp" if settings.SMTP_HOST else "console"),
    }


@router.get("/analytics/events")
async def analytics_events(limit: int = 30, user: UserResponse = Depends(_require_user)):
    from app.services import analytics as analytics_service
    return analytics_service.recent_events(limit=limit, user_id=user.id)


@router.post("/admin/cleanup")
async def cleanup_old_jobs(user: UserResponse = Depends(_require_user)):
    """Delete outputs older than JOB_RETENTION_DAYS for the current user + expired tokens."""
    from app.services.cleanup import cleanup_old_outputs
    stats = cleanup_old_outputs(user_id=user.id)
    return stats


@router.get("/ready")
async def readiness():
    """K8s/Docker readiness: DB must be reachable."""
    from sqlalchemy import text
    from app.db.database import engine
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        return {"status": "ready", "version": settings.VERSION}
    except Exception as e:
        raise HTTPException(503, f"not ready: {e}")

"""Text-to-Speech using edge-tts (free, high quality neural voices)."""
import asyncio
import logging
from pathlib import Path
from typing import List, Optional

import edge_tts

from app.core.config import settings
from app.models.schemas import TranscriptSegment

logger = logging.getLogger(__name__)


async def generate_speech(
    text: str,
    output_path: Path,
    voice: str = "en-US-JennyNeural",
    rate: str = "+0%",
) -> Path:
    """Generate a single audio file from full text."""
    logger.info(f"Generating TTS with voice={voice}")
    communicate = edge_tts.Communicate(text, voice, rate=rate)
    await communicate.save(str(output_path))
    logger.info(f"TTS saved to {output_path}")
    return output_path


async def generate_speech_with_timestamps(
    text: str,
    output_path: Path,
    voice: str = "en-US-JennyNeural",
) -> tuple[Path, List[TranscriptSegment]]:
    """
    Generate speech and approximate word/segment timestamps.
    For Phase 1 we use the full text and later align via Whisper if needed,
    or simple proportional timing.
    """
    # First generate the audio
    await generate_speech(text, output_path, voice)
    
    # For better captions we re-transcribe the generated audio
    # so we get accurate timings matching the actual TTS speech.
    from app.services.transcription import transcribe_audio
    segments = transcribe_audio(output_path)
    return output_path, segments


def split_text_into_sentences(text: str) -> List[str]:
    """Very simple sentence splitter."""
    import re
    sentences = re.split(r'(?<=[.!?])\s+', text.strip())
    return [s.strip() for s in sentences if s.strip()]


async def list_available_voices(locale: str = "en") -> List[dict]:
    """List available edge-tts voices filtered by locale."""
    voices = await edge_tts.list_voices()
    return [
        {"name": v["ShortName"], "gender": v["Gender"], "locale": v["Locale"]}
        for v in voices
        if v["Locale"].startswith(locale)
    ]

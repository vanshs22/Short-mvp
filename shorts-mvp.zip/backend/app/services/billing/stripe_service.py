"""Stripe checkout for subscriptions and credit packs (Phase 3).

Production: set STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET, and optionally
STRIPE_PRICE_PRO / STRIPE_PRICE_STUDIO / STRIPE_PRICE_PACK_* for pre-created
Price IDs (recommended). Falls back to inline price_data when Price IDs unset.
"""
from __future__ import annotations

import logging
from typing import Optional

import stripe

from app.core.config import settings
from app.services import users as user_service

logger = logging.getLogger(__name__)

stripe.api_key = settings.STRIPE_SECRET_KEY

# Idempotency: track processed event IDs in-memory (OK for single instance;
# use Redis/DB for multi-worker in production).
_processed_events: set[str] = set()
_MAX_PROCESSED = 5000


def _is_configured() -> bool:
    return bool(settings.STRIPE_SECRET_KEY) and not settings.STRIPE_SECRET_KEY.startswith(
        "sk_test_placeholder"
    )


def _price_id(kind: str) -> Optional[str]:
    """Optional pre-created Stripe Price IDs from env."""
    mapping = {
        "subscription_pro": getattr(settings, "STRIPE_PRICE_PRO", "") or "",
        "subscription_studio": getattr(settings, "STRIPE_PRICE_STUDIO", "") or "",
        "pack_50": getattr(settings, "STRIPE_PRICE_PACK_50", "") or "",
        "pack_150": getattr(settings, "STRIPE_PRICE_PACK_150", "") or "",
        "pack_500": getattr(settings, "STRIPE_PRICE_PACK_500", "") or "",
    }
    pid = mapping.get(kind, "")
    return pid or None


def create_checkout_session(user_id: str, email: str, kind: str) -> dict:
    """
    kind: subscription_pro | subscription_studio | pack_50 | pack_150 | pack_500
    Returns {checkout_url, session_id}
    """
    if not _is_configured():
        logger.warning("Stripe not configured — simulating checkout grant")
        return _simulate_checkout(user_id, kind)

    metadata = {"user_id": user_id, "kind": kind}
    price_id = _price_id(kind)

    if kind.startswith("subscription_"):
        plan = kind.replace("subscription_", "")
        if price_id:
            line_items = [{"price": price_id, "quantity": 1}]
        else:
            price_cents = settings.PRO_PRICE_CENTS if plan == "pro" else settings.STUDIO_PRICE_CENTS
            label = f"Shorts MVP {plan.title()} monthly"
            line_items = [{
                "price_data": {
                    "currency": "usd",
                    "product_data": {"name": label},
                    "unit_amount": price_cents,
                    "recurring": {"interval": "month"},
                },
                "quantity": 1,
            }]
        session = stripe.checkout.Session.create(
            mode="subscription",
            customer_email=email,
            line_items=line_items,
            success_url=settings.STRIPE_SUCCESS_URL + "&session_id={CHECKOUT_SESSION_ID}",
            cancel_url=settings.STRIPE_CANCEL_URL,
            metadata=metadata,
            subscription_data={"metadata": metadata},
            client_reference_id=user_id,
        )
    elif kind in settings.CREDIT_PACKS:
        pack = settings.CREDIT_PACKS[kind]
        if price_id:
            line_items = [{"price": price_id, "quantity": 1}]
        else:
            line_items = [{
                "price_data": {
                    "currency": "usd",
                    "product_data": {"name": pack["label"]},
                    "unit_amount": pack["price_cents"],
                },
                "quantity": 1,
            }]
        session = stripe.checkout.Session.create(
            mode="payment",
            customer_email=email,
            line_items=line_items,
            success_url=settings.STRIPE_SUCCESS_URL + "&session_id={CHECKOUT_SESSION_ID}",
            cancel_url=settings.STRIPE_CANCEL_URL,
            metadata=metadata,
            client_reference_id=user_id,
        )
    else:
        raise ValueError(f"Unknown checkout kind: {kind}")

    return {"checkout_url": session.url, "session_id": session.id}


def _simulate_checkout(user_id: str, kind: str) -> dict:
    if kind == "subscription_pro":
        user_service.set_plan(user_id, "pro")
    elif kind == "subscription_studio":
        user_service.set_plan(user_id, "studio")
    elif kind in settings.CREDIT_PACKS:
        credits = settings.CREDIT_PACKS[kind]["credits"]
        user_service.add_credits(user_id, credits, reason=f"sim_{kind}")
    else:
        raise ValueError(f"Unknown checkout kind: {kind}")
    return {
        "checkout_url": f"/?billing=simulated&kind={kind}",
        "session_id": f"sim_{kind}_{user_id[:8]}",
    }


def _apply_checkout(user_id: str, kind: str, data: dict) -> dict:
    if kind.startswith("subscription_"):
        plan = kind.replace("subscription_", "")
        user_service.set_plan(
            user_id,
            plan,
            stripe_sub_id=data.get("subscription"),
            stripe_customer_id=data.get("customer"),
        )
    elif kind in settings.CREDIT_PACKS:
        credits = settings.CREDIT_PACKS[kind]["credits"]
        user_service.add_credits(
            user_id, credits, reason=kind, stripe_payment_id=data.get("payment_intent")
        )
    else:
        return {"status": "unknown_kind", "kind": kind}
    return {"status": "ok", "kind": kind, "user_id": user_id}


def handle_webhook_event(payload: bytes, sig_header: str) -> dict:
    if not _is_configured():
        return {"status": "ignored", "reason": "stripe not configured"}

    try:
        event = stripe.Webhook.construct_event(
            payload, sig_header, settings.STRIPE_WEBHOOK_SECRET
        )
    except stripe.error.SignatureVerificationError as e:
        logger.error(f"Webhook signature verification failed: {e}")
        raise
    except Exception as e:
        logger.error(f"Webhook construct failed: {e}")
        raise

    event_id = event.get("id") or ""
    if event_id and event_id in _processed_events:
        return {"status": "duplicate", "event_id": event_id}

    etype = event["type"]
    data = event["data"]["object"]
    result: dict = {"status": "unhandled", "type": etype}

    if etype == "checkout.session.completed":
        meta = data.get("metadata") or {}
        user_id = meta.get("user_id") or data.get("client_reference_id")
        kind = meta.get("kind")
        if not user_id or not kind:
            result = {"status": "missing_meta"}
        else:
            result = _apply_checkout(user_id, kind, data)

    elif etype == "customer.subscription.deleted":
        # Downgrade to free on cancel
        meta = data.get("metadata") or {}
        user_id = meta.get("user_id")
        if user_id:
            user_service.set_plan(user_id, "free")
            result = {"status": "ok", "action": "downgraded", "user_id": user_id}

    elif etype == "invoice.payment_failed":
        logger.warning(f"Payment failed for customer {data.get('customer')}")
        result = {"status": "logged", "type": etype}

    if event_id:
        _processed_events.add(event_id)
        if len(_processed_events) > _MAX_PROCESSED:
            # Drop oldest arbitrarily
            for _ in range(1000):
                _processed_events.pop()

    return result

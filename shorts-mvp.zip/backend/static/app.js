let mode = 'ai', template = 'standard', pollTimer = null, currentJobId = null;
let token = localStorage.getItem('shorts_token') || null;
let authMode = 'login';
let currentUser = null;

function authHeaders() {
  return token ? { 'Authorization': 'Bearer ' + token } : {};
}

function apiError(data, fallback) {
  if (!data) return fallback || 'Request failed';
  const d = data.detail;
  if (typeof d === 'string') return d;
  if (Array.isArray(d)) return d.map(x => x.msg || JSON.stringify(x)).join('; ');
  if (d && typeof d === 'object') return d.msg || JSON.stringify(d);
  return data.message || fallback || 'Request failed';
}

function setTemplate(t) {
  template = t;
  document.querySelectorAll('#nav-tabs [data-tmpl]').forEach(b => {
    const on = b.dataset.tmpl === t;
    b.classList.toggle('tab-on', on);
    b.classList.toggle('tab', !on);
  });
  document.querySelectorAll('#nav-tabs [data-view]').forEach(b => {
    b.classList.remove('tab-on');
    b.classList.add('tab');
  });
  document.getElementById('main-panels').classList.remove('hidden');
  document.getElementById('billing-panel').classList.add('hidden');
  document.getElementById('dash-panel').classList.add('hidden');

  const map = {
    standard: 'panel-standard',
    reddit_story: 'panel-reddit',
    fake_text: 'panel-fake',
    split_screen: 'panel-split',
    youtube_reels: 'panel-youtube',
    ai_visual: 'panel-ai_visual',
  };
  Object.values(map).forEach(id => {
    const el = document.getElementById(id);
    if (el) el.classList.add('hidden');
  });
  const show = map[t];
  if (show) document.getElementById(show).classList.remove('hidden');

  const btn = document.getElementById('submit-btn');
  if (t === 'youtube_reels') btn.textContent = 'Generate Reels from YouTube';
  else if (t === 'ai_visual') btn.textContent = 'Generate AI Visual Reel';
  else btn.textContent = 'Generate Short';
}

function setMode(m) {
  mode = m;
  document.getElementById('ai-panel').classList.toggle('hidden', m !== 'ai');
  document.getElementById('upload-panel').classList.toggle('hidden', m !== 'upload');
  const sp = document.getElementById('script-panel');
  if (m === 'upload') sp.classList.add('hidden');
  else sp.classList.remove('hidden');
  ['ai', 'script', 'upload'].forEach(x => {
    const el = document.getElementById('mode-' + x);
    if (!el) return;
    el.className = m === x
      ? 'chip px-2.5 py-1 rounded-md'
      : 'px-2.5 py-1 rounded-md text-[11px] uppercase tracking-wide text-mist-500';
  });
}

async function generateAIScript() {
  const topic = document.getElementById('ai_topic').value.trim();
  const brief = document.getElementById('ai_brief').value.trim();
  const tone = document.getElementById('ai_tone').value;
  const length = document.getElementById('ai_length').value;
  const st = document.getElementById('ai-status');
  if (!topic) { st.classList.remove('hidden'); st.textContent = 'Enter a topic first.'; return; }
  st.classList.remove('hidden');
  st.textContent = 'Writing script…';
  try {
    const res = await fetch('/api/generate-script', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...authHeaders() },
      body: JSON.stringify({ topic, brief, tone, length, language: 'en' }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(apiError(data, 'Script generation failed'));
    document.getElementById('script').value = data.script;
    document.getElementById('script-panel').classList.remove('hidden');
    st.textContent = 'Script ready (' + data.provider + (data.model ? ' · ' + data.model : '') + '). Edit if needed, then generate.';
  } catch (e) {
    st.textContent = e.message || 'Failed';
  }
}

async function loadBackgrounds() {
  try {
    const res = await fetch('/api/backgrounds');
    if (!res.ok) return;
    const items = await res.json();
    const sel = document.getElementById('background');
    (items || []).forEach(b => {
      const o = document.createElement('option');
      o.value = b.id;
      o.textContent = b.name || b.id;
      sel.appendChild(o);
    });
  } catch (_) {}
}

async function loadJobs() {
  try {
    const res = await fetch('/api/jobs', { headers: authHeaders() });
    if (!res.ok) return;
    const jobs = await res.json();
    const el = document.getElementById('jobs-list');
    if (!jobs || !jobs.length) { el.textContent = 'No jobs yet.'; return; }
    el.innerHTML = jobs.slice(0, 12).map(j => {
      const url = j.output_url || '';
      const link = url ? `<a href="${url}" class="text-sand-400 hover:underline ml-2" target="_blank" rel="noopener">open</a>` : '';
      return `<div class="flex items-center justify-between gap-2 py-2 border-b border-white/[0.04]">
        <span class="truncate text-mist-300">${(j.template || 'job')} · ${(j.id || '').slice(0, 8)}</span>
        <span class="text-mist-500 shrink-0">${j.status || '—'}${link}</span>
      </div>`;
    }).join('');
  } catch (_) {
    document.getElementById('jobs-list').textContent = '—';
  }
}

async function refreshAuthUI() {
  const area = document.getElementById('auth-area');
  if (!token) {
    currentUser = null;
    area.innerHTML = `
      <button type="button" onclick="showAuth('login')" class="btn-ghost px-3 py-1.5 rounded-lg text-sm">Log in</button>
      <button type="button" onclick="showAuth('register')" class="btn-primary px-3 py-1.5 rounded-lg text-sm">Sign up</button>`;
    return;
  }
  try {
    const res = await fetch('/api/auth/me', { headers: authHeaders() });
    if (!res.ok) { logout(false); return; }
    currentUser = await res.json();
    area.innerHTML = `
      <span class="text-mist-500 text-xs sm:text-sm">${currentUser.plan || 'free'} · ${currentUser.credits_remaining ?? '—'} credits</span>
      <button type="button" onclick="logout()" class="btn-ghost px-3 py-1.5 rounded-lg text-sm">Log out</button>`;
  } catch (_) {
    logout(false);
  }
}

function showAuth(m) {
  authMode = m;
  document.getElementById('auth-title').textContent = m === 'register' ? 'Create account' : 'Log in';
  document.getElementById('auth-name').classList.toggle('hidden', m !== 'register');
  document.getElementById('auth-error').classList.add('hidden');
  const modal = document.getElementById('auth-modal');
  modal.classList.remove('hidden');
  modal.classList.add('flex');
}

function closeAuth() {
  const modal = document.getElementById('auth-modal');
  modal.classList.add('hidden');
  modal.classList.remove('flex');
}

async function submitAuth() {
  const email = document.getElementById('auth-email').value.trim();
  const password = document.getElementById('auth-password').value;
  const name = document.getElementById('auth-name').value.trim();
  const errEl = document.getElementById('auth-error');
  errEl.classList.add('hidden');
  try {
    if (authMode === 'register') {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password, name: name || null }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(apiError(data, 'Registration failed'));
    }
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(apiError(data, 'Login failed'));
    token = data.token;
    localStorage.setItem('shorts_token', token);
    closeAuth();
    await refreshAuthUI();
    loadJobs();
  } catch (e) {
    errEl.textContent = e.message || 'Failed';
    errEl.classList.remove('hidden');
  }
}

async function logout(callApi) {
  if (callApi !== false && token) {
    try { await fetch('/api/auth/logout', { method: 'POST', headers: authHeaders() }); } catch (_) {}
  }
  token = null;
  currentUser = null;
  localStorage.removeItem('shorts_token');
  refreshAuthUI();
}

async function showBilling() {
  document.getElementById('main-panels').classList.add('hidden');
  document.getElementById('dash-panel').classList.add('hidden');
  document.getElementById('billing-panel').classList.remove('hidden');
  document.querySelectorAll('#nav-tabs [data-tmpl]').forEach(b => { b.classList.remove('tab-on'); b.classList.add('tab'); });
  document.querySelectorAll('#nav-tabs [data-view]').forEach(b => {
    b.classList.toggle('tab-on', b.dataset.view === 'billing');
    b.classList.toggle('tab', b.dataset.view !== 'billing');
  });
  const el = document.getElementById('plans-list');
  try {
    const res = await fetch('/api/billing/plans');
    const data = await res.json();
    const plans = data.plans || [];
    const packs = data.packs || [];
    const stripeOk = !!data.stripe_configured;
    const cryptoOk = !!data.crypto_configured;
    const mode = data.payment_mode || (stripeOk || cryptoOk ? 'live' : 'simulate');
    let html = `<p class="text-xs text-mist-500 mb-4">Mode: <span class="text-mist-300">${mode}</span> · Stripe ${stripeOk ? 'live keys' : 'not configured'} · Crypto ${cryptoOk ? 'live keys' : 'not configured'}${mode === 'simulate' ? ' (dev grants until you add keys)' : ' — real charges'}</p>`;
    html += '<div class="text-xs uppercase tracking-wider text-mist-500 mb-2">Plans</div>';
    plans.forEach(p => {
      const kind = p.checkout_kind;
      const actions = kind ? `
        <div class="flex gap-2 shrink-0">
          <button type="button" onclick="buy('${kind}','stripe')" class="btn-ghost px-3 py-1.5 rounded-lg text-xs">Card</button>
          <button type="button" onclick="buy('${kind}','crypto')" class="btn-ghost px-3 py-1.5 rounded-lg text-xs">Crypto</button>
        </div>` : `<span class="text-xs text-mist-500">Current free tier</span>`;
      html += `<div class="flex justify-between items-center gap-3 py-3 border-b border-white/[0.05]">
        <div>
          <div class="text-mist-200 font-medium">${p.name} · ${p.price_label || ''}</div>
          <div class="text-xs text-mist-500">${p.blurb || ''} · ${p.credits_monthly || 0} credits/mo · ${p.max_concurrent_jobs || 1} parallel jobs</div>
        </div>
        ${actions}
      </div>`;
    });
    html += '<div class="text-xs uppercase tracking-wider text-mist-500 mt-5 mb-2">Credit packs</div>';
    packs.forEach(p => {
      html += `<div class="flex justify-between items-center gap-3 py-3 border-b border-white/[0.05]">
        <div>
          <div class="text-mist-200 font-medium">${p.name}</div>
          <div class="text-xs text-mist-500">${p.blurb || ''}</div>
        </div>
        <div class="flex gap-2 shrink-0">
          <button type="button" onclick="buy('${p.checkout_kind || p.id}','stripe')" class="btn-ghost px-3 py-1.5 rounded-lg text-xs">Card</button>
          <button type="button" onclick="buy('${p.checkout_kind || p.id}','crypto')" class="btn-ghost px-3 py-1.5 rounded-lg text-xs">Crypto</button>
        </div>
      </div>`;
    });
    el.innerHTML = html;
  } catch (e) {
    el.textContent = 'Could not load plans.';
  }
}

async function buy(kind, provider) {
  if (!token) { showAuth('login'); return; }
  provider = provider || 'stripe';
  try {
    const res = await fetch('/api/billing/checkout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...authHeaders() },
      body: JSON.stringify({ kind, provider }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(apiError(data, 'Checkout failed'));
    if (data.checkout_url) {
      if (data.checkout_url.startsWith('/')) {
        alert(provider === 'crypto' ? 'Crypto payment recorded (or simulated). Credits updated.' : 'Payment recorded (simulated). Credits updated.');
        await refreshAuthUI();
        window.history.replaceState({}, '', data.checkout_url);
      } else {
        window.location.href = data.checkout_url;
      }
    } else {
      alert('Purchase recorded.');
      refreshAuthUI();
    }
  } catch (e) {
    alert(e.message || 'Failed');
  }
}

async function showDashboard() {
  document.getElementById('main-panels').classList.add('hidden');
  document.getElementById('billing-panel').classList.add('hidden');
  document.getElementById('dash-panel').classList.remove('hidden');
  document.querySelectorAll('#nav-tabs [data-tmpl]').forEach(b => { b.classList.remove('tab-on'); b.classList.add('tab'); });
  document.querySelectorAll('#nav-tabs [data-view]').forEach(b => {
    b.classList.toggle('tab-on', b.dataset.view === 'dash');
    b.classList.toggle('tab', b.dataset.view !== 'dash');
  });
  if (!token) {
    document.getElementById('dash-content').textContent = 'Log in to view dashboard.';
    return;
  }
  try {
    const res = await fetch('/api/dashboard', { headers: authHeaders() });
    const d = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(apiError(d, 'Failed'));
    const u = d.user || d;
    const lim = d.limits || d.usage || {};
    document.getElementById('dash-content').innerHTML = `
      <div class="grid grid-cols-2 gap-4">
        <div class="p-3 rounded-xl bg-ink-900 border border-white/[0.05]">
          <div class="text-xs text-mist-500 mb-1">Plan</div>
          <div class="text-mist-100 font-medium">${u.plan || lim.plan || '—'}</div>
        </div>
        <div class="p-3 rounded-xl bg-ink-900 border border-white/[0.05]">
          <div class="text-xs text-mist-500 mb-1">Credits</div>
          <div class="text-mist-100 font-medium">${u.credits_remaining ?? lim.credits_remaining ?? '—'}</div>
        </div>
        <div class="p-3 rounded-xl bg-ink-900 border border-white/[0.05]">
          <div class="text-xs text-mist-500 mb-1">Videos this week</div>
          <div class="text-mist-100 font-medium">${u.videos_this_week ?? '—'}</div>
        </div>
        <div class="p-3 rounded-xl bg-ink-900 border border-white/[0.05]">
          <div class="text-xs text-mist-500 mb-1">Storage</div>
          <div class="text-mist-100 font-medium">${lim.storage_used_mb ?? 0} / ${lim.storage_limit_mb ?? '—'} MB</div>
        </div>
      </div>`;
  } catch (e) {
    document.getElementById('dash-content').textContent = e.message || 'Failed to load';
  }
}

function badgeClass(status) {
  const s = (status || '').toLowerCase();
  if (s === 'completed') return 'badge-completed';
  if (s === 'failed' || s === 'cancelled') return 'badge-failed';
  if (s.includes('process') || s.includes('generat') || s.includes('compos') || s.includes('transcrib')) return 'badge-processing';
  return 'badge-pending';
}

function showStatus(job) {
  currentJobId = job.id;
  const card = document.getElementById('status-card');
  card.classList.remove('hidden');
  const badge = document.getElementById('status-badge');
  badge.textContent = job.status;
  badge.className = 'text-xs px-2.5 py-1 rounded-full ' + badgeClass(job.status);
  document.getElementById('status-msg').textContent = job.message || '—';
  document.getElementById('progress-bar').style.width = Math.min(100, Number(job.progress) || 0) + '%';
  const err = document.getElementById('error-msg');
  if (job.error) {
    err.textContent = job.error;
    err.classList.remove('hidden');
  } else {
    err.classList.add('hidden');
  }
  const cancelBtn = document.getElementById('cancel-btn');
  const active = ['pending', 'processing', 'transcribing', 'generating_voice', 'composing'].includes((job.status || '').toLowerCase());
  cancelBtn.classList.toggle('hidden', !active);

  const result = document.getElementById('result-area');
  if ((job.status || '').toLowerCase() === 'completed' && job.output_url) {
    result.classList.remove('hidden');
    document.getElementById('result-video').src = job.output_url;
    document.getElementById('download-link').href = job.output_url;
    const extra = document.getElementById('extra-outputs');
    const outs = job.extra_outputs || [];
    extra.innerHTML = outs.length > 1
      ? outs.map((u, i) => `<a href="${u}" target="_blank" rel="noopener" class="text-sand-400 hover:underline">Reel ${i + 1}</a>`).join('')
      : '';
    document.getElementById('submit-btn').disabled = false;
    refreshAuthUI();
    loadJobs();
  } else if (['failed', 'cancelled'].includes((job.status || '').toLowerCase())) {
    result.classList.add('hidden');
    document.getElementById('submit-btn').disabled = false;
    refreshAuthUI();
  } else {
    result.classList.add('hidden');
  }
}

function pollJob(id) {
  if (pollTimer) clearInterval(pollTimer);
  pollTimer = setInterval(async () => {
    try {
      const res = await fetch('/api/jobs/' + id, { headers: authHeaders() });
      if (!res.ok) return;
      const job = await res.json();
      showStatus(job);
      if (['completed', 'failed', 'cancelled'].includes((job.status || '').toLowerCase())) {
        clearInterval(pollTimer);
      }
    } catch (_) {}
  }, 1500);
}

async function cancelCurrentJob() {
  if (!currentJobId) return;
  try {
    const res = await fetch('/api/jobs/' + currentJobId + '/cancel', {
      method: 'POST',
      headers: authHeaders(),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(apiError(data, 'Cancel failed'));
    showStatus(data);
  } catch (e) {
    alert(e.message || 'Cancel failed');
  }
}

async function tweakStyle() {
  if (!currentJobId) return;
  const style = document.getElementById('style').value;
  try {
    const res = await fetch('/api/jobs/' + currentJobId + '/tweak', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...authHeaders() },
      body: JSON.stringify({ caption_style: style }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(apiError(data, 'Tweak failed'));
    showStatus(data);
    if (data.id) pollJob(data.id);
  } catch (e) {
    alert(e.message || 'Tweak failed');
  }
}

document.getElementById('job-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = document.getElementById('submit-btn');
  btn.disabled = true;
  const fd = new FormData();
  fd.append('template', template);
  fd.append('voice', document.getElementById('voice').value);
  fd.append('caption_style', document.getElementById('style').value);
  const bg = document.getElementById('background').value;
  if (bg) fd.append('background_id', bg);
  const mc = document.getElementById('manual_captions').value.trim();
  if (mc) fd.append('manual_captions', mc);

  try {
    if (template === 'standard') {
      if (mode === 'upload') {
        const file = document.getElementById('file').files[0];
        if (!file) throw new Error('Choose a file');
        fd.append('file', file);
      } else {
        const script = document.getElementById('script').value.trim();
        if (!script) throw new Error('Enter or generate a script first');
        fd.append('script', script);
      }
    } else if (template === 'ai_visual') {
      const topic = document.getElementById('ai_visual_topic').value.trim();
      const script = document.getElementById('ai_visual_script').value.trim();
      if (!topic && !script) throw new Error('Enter a topic or script');
      if (script) fd.append('script', script);
      if (topic) fd.append('ai_topic', topic);
      fd.append('ai_max_scenes', document.getElementById('ai_max_scenes').value);
      fd.append('ai_image_style', document.getElementById('ai_image_style').value);
    } else if (template === 'reddit_story') {
      const title = document.getElementById('reddit_title').value.trim();
      const body = document.getElementById('reddit_body').value.trim();
      if (!title || !body) throw new Error('Title and body required');
      fd.append('reddit_title', title);
      fd.append('reddit_body', body);
      fd.append('reddit_subreddit', document.getElementById('reddit_subreddit').value);
      fd.append('reddit_username', document.getElementById('reddit_username').value);
      fd.append('reddit_upvotes', document.getElementById('reddit_upvotes').value);
    } else if (template === 'fake_text') {
      const raw = document.getElementById('fake_messages').value.trim();
      if (!raw) throw new Error('Add messages');
      const messages = raw.split('\n').filter(Boolean).map(line => {
        const lower = line.toLowerCase();
        let is_me = false, text = line;
        if (lower.startsWith('me:')) { is_me = true; text = line.slice(3).trim(); }
        else if (lower.startsWith('them:')) { text = line.slice(5).trim(); }
        return { sender: is_me ? 'me' : 'them', text, is_me };
      });
      fd.append('fake_text_json', JSON.stringify(messages));
      fd.append('fake_contact', document.getElementById('fake_contact').value);
      fd.append('fake_platform', document.getElementById('fake_platform').value);
      fd.append('fake_narrate', document.getElementById('fake_narrate').checked);
    } else if (template === 'youtube_reels') {
      const url = document.getElementById('youtube_url').value.trim();
      if (!url) throw new Error('Paste a YouTube URL');
      fd.append('youtube_url', url);
      fd.append('youtube_max_clips', document.getElementById('youtube_max_clips').value);
      fd.append('youtube_min_sec', document.getElementById('youtube_min_sec').value);
      fd.append('youtube_max_sec', document.getElementById('youtube_max_sec').value);
      fd.append('youtube_captions', document.getElementById('youtube_captions').checked);
    } else if (template === 'split_screen') {
      const script = document.getElementById('split_script').value.trim();
      if (!script) throw new Error('Enter a script');
      fd.append('script', script);
      fd.append('split_label', document.getElementById('split_label').value);
    }

    const res = await fetch('/api/jobs', { method: 'POST', body: fd, headers: authHeaders() });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(apiError(data, 'Job failed'));
    showStatus(data);
    pollJob(data.id);
  } catch (err) {
    alert(err.message || 'Failed');
    btn.disabled = false;
  }
});

setMode('ai');
loadBackgrounds();
loadJobs();
refreshAuthUI();
if (new URLSearchParams(location.search).get('billing') === 'success') refreshAuthUI();

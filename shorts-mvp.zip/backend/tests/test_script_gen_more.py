"""Script generation edge cases."""
from app.services.script_gen import _local_script
import asyncio
from app.services.script_gen import generate_script


def test_local_tones():
    for tone in ("engaging", "educational", "story", "hype", "calm"):
        s = _local_script("focus", "one tip", tone, "short")
        assert len(s) > 40


def test_local_lengths():
    short = _local_script("X", "a. b. c.", "engaging", "short")
    long = _local_script("X", "a. b. c.", "engaging", "long")
    assert len(long) >= len(short)


def test_generate_requires_topic():
    try:
        asyncio.get_event_loop().run_until_complete(generate_script(""))
        assert False
    except ValueError:
        pass


def test_api_rejects_empty_topic(client):
    r = client.post("/api/generate-script", json={"topic": "x"})  # min_length 2 in schema - "x" might fail
    # topic min 2 chars - single char may 422
    r2 = client.post("/api/generate-script", json={"topic": "ab", "brief": "ok"})
    assert r2.status_code == 200


def test_api_script_contains_topic(client):
    r = client.post("/api/generate-script", json={
        "topic": "hydration myths",
        "brief": "people drink too little water at work",
        "tone": "educational",
        "length": "medium",
    })
    assert r.status_code == 200
    assert "hydration" in r.json()["script"].lower() or "water" in r.json()["script"].lower() or len(r.json()["script"]) > 50

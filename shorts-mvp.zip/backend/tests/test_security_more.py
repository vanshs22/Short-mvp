"""Additional security coverage."""
from fastapi import HTTPException
from app.services.security import assert_safe_external_url, escape_ffmpeg_path
from app.services.upload_security import safe_output_path
from app.core.config import settings
import pytest


def test_ssrf_credentials_blocked():
    with pytest.raises(HTTPException):
        assert_safe_external_url("https://user:pass@evil.com/")


def test_ssrf_ftp_blocked():
    with pytest.raises(HTTPException):
        assert_safe_external_url("ftp://files.example.com/x")


def test_youtube_host_allowlist():
    url = assert_safe_external_url(
        "https://youtu.be/dQw4w9WgXcQ",
        allow_hosts=("youtube.com", "www.youtube.com", "youtu.be"),
    )
    assert "youtu.be" in url or "youtube" in url


def test_escape_ffmpeg_brackets():
    s = escape_ffmpeg_path("/tmp/foo[bar].srt")
    assert "[" not in s or "\\[" in s


def test_safe_output_rejects_slash():
    with pytest.raises(Exception):
        safe_output_path("../../etc/passwd", settings.OUTPUT_DIR)


def test_outputs_api_traversal(client):
    r = client.get("/api/outputs/..%2F..%2Fetc%2Fpasswd")
    assert r.status_code in (400, 404)

"""Users / credits edge cases."""
from app.services import users as user_service
import uuid


def test_register_login_flow():
    email = f"t_{uuid.uuid4().hex[:10]}@example.com"
    u = user_service.create_user(email, "password12345", name="T")
    assert u.id
    u2, token = user_service.authenticate(email, "password12345")
    assert u2.id == u.id
    assert token


def test_bad_login():
    email = f"t_{uuid.uuid4().hex[:10]}@example.com"
    user_service.create_user(email, "password12345", name="T")
    try:
        user_service.authenticate(email, "wrong-password-xx")
        assert False
    except ValueError:
        pass


def test_usage_limits_free():
    email = f"t_{uuid.uuid4().hex[:10]}@example.com"
    u = user_service.create_user(email, "password12345", name="T")
    lim = user_service.usage_limits(u.id)
    assert lim.credits_remaining >= 0

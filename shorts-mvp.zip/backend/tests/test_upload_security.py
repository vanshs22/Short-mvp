"""Upload validation + path traversal tests."""
from pathlib import Path
from unittest.mock import MagicMock

import pytest
from fastapi import HTTPException

from app.services.upload_security import (
    validate_upload,
    safe_output_path,
    ALLOWED_UPLOAD_EXTS,
)


def _file(name: str, content_type: str = "video/mp4"):
    f = MagicMock()
    f.filename = name
    f.content_type = content_type
    return f


def test_rejects_bad_extension():
    content = b"\x00\x00\x00\x18ftypmp42" + b"\x00" * 32
    with pytest.raises(HTTPException) as ei:
        validate_upload(_file("evil.exe"), content)
    assert ei.value.status_code == 400


def test_rejects_empty():
    with pytest.raises(HTTPException) as ei:
        validate_upload(_file("a.mp4"), b"")
    assert ei.value.status_code == 400


def test_accepts_mp4_magic():
    content = b"\x00\x00\x00\x18ftypmp42" + b"\x00" * 64
    ext, stem = validate_upload(_file("clip.mp4"), content)
    assert ext == ".mp4"
    assert stem == "clip"


def test_rejects_fake_extension_bad_magic():
    content = b"this is not a video file at all!!!!"
    with pytest.raises(HTTPException) as ei:
        validate_upload(_file("clip.mp4"), content)
    assert ei.value.status_code == 400


def test_path_traversal_blocked(tmp_path):
    with pytest.raises(HTTPException):
        safe_output_path("../etc/passwd", tmp_path)
    with pytest.raises(HTTPException):
        safe_output_path("../../secret", tmp_path)


def test_path_ok(tmp_path):
    p = safe_output_path("job123.mp4", tmp_path)
    assert p.name == "job123.mp4"
    assert p.parent == tmp_path.resolve()

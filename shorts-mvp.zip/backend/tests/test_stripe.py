"""Stripe service: simulated mode + kind validation."""
import pytest
from app.services.billing import stripe_service
from app.services import users as user_service


def test_simulate_pack():
    email = f"stripe_{id(object())}@example.com"
    user = user_service.create_user(email, "StripeTest1")
    before = user.credits_remaining
    result = stripe_service.create_checkout_session(user.id, email, "pack_50")
    assert "session_id" in result
    assert result["session_id"].startswith("sim_")
    limits = user_service.usage_limits(user.id)
    assert limits.credits_remaining == before + 50


def test_simulate_pro():
    email = f"pro_{id(object())}@example.com"
    user = user_service.create_user(email, "StripeTest1")
    stripe_service.create_checkout_session(user.id, email, "subscription_pro")
    limits = user_service.usage_limits(user.id)
    assert limits.plan == "pro"


def test_unknown_kind():
    email = f"badk_{id(object())}@example.com"
    user = user_service.create_user(email, "StripeTest1")
    with pytest.raises(ValueError):
        stripe_service.create_checkout_session(user.id, email, "not_a_real_kind")

from app.services.youtube import is_youtube_url, normalize_url


def test_youtube_urls():
    assert is_youtube_url("https://www.youtube.com/watch?v=dQw4w9WgXcQ")
    assert is_youtube_url("https://youtu.be/dQw4w9WgXcQ")
    assert is_youtube_url("youtube.com/watch?v=abc123")
    assert not is_youtube_url("https://example.com/video")
    assert not is_youtube_url("")


def test_normalize():
    assert normalize_url("youtu.be/abc").startswith("https://")

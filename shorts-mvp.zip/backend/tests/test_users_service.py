"""Direct unit tests for users service (no HTTP)."""
from __future__ import annotations

import pytest
from app.services import users as user_service


def test_create_and_auth():
    email = f"unit_{id(object())}@example.com"
    password = "UnitTest99"
    user = user_service.create_user(email, password, name="Unit")
    assert user.email == email
    assert user.credits_remaining > 0

    u2, token = user_service.authenticate(email, password)
    assert u2.id == user.id
    assert token

    loaded = user_service.get_user_by_token(token)
    assert loaded is not None
    assert loaded.id == user.id


def test_bad_password_raises():
    email = f"bad_{id(object())}@example.com"
    user_service.create_user(email, "GoodPass1", name="B")
    with pytest.raises(ValueError):
        user_service.authenticate(email, "Wrong999")


def test_credit_consume():
    email = f"credit_{id(object())}@example.com"
    user = user_service.create_user(email, "GoodPass1")
    ok = user_service.check_and_consume_credit(user.id, cost=1)
    assert ok is True
    limits = user_service.usage_limits(user.id)
    assert limits.credits_remaining == user.credits_remaining - 1


def test_password_policy():
    with pytest.raises(ValueError):
        user_service.create_user("p1@example.com", "short")
    with pytest.raises(ValueError):
        user_service.create_user("p2@example.com", "nodigits")
    with pytest.raises(ValueError):
        user_service.create_user("p3@example.com", "12345678")


def test_logout_invalidates():
    email = f"logout_{id(object())}@example.com"
    user_service.create_user(email, "GoodPass1")
    _, token = user_service.authenticate(email, "GoodPass1")
    assert user_service.get_user_by_token(token) is not None
    assert user_service.logout(token) is True
    assert user_service.get_user_by_token(token) is None

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONPATH=.
mkdir -p uploads outputs backgrounds temp data assets
if [[ ! -f .env && -f .env.example ]]; then
  cp .env.example .env
fi

if [[ "${SKIP_DEP_INSTALL:-0}" != "1" ]]; then
  PYBIN="python3"; command -v python3 >/dev/null 2>&1 || PYBIN="python"
  "$PYBIN" -m pip install -q -r requirements.txt
  "$PYBIN" -m pip install -q -U yt-dlp
fi

CONCURRENCY="${CELERY_CONCURRENCY:-2}"
echo "Starting Celery worker (concurrency=$CONCURRENCY) broker=${CELERY_BROKER_URL:-redis://localhost:6379/0}"
exec celery -A app.workers.celery_app.celery_app worker -l info --concurrency="$CONCURRENCY"

# Shorts MVP — Run Guide

## Quick start (single process, no Redis)

**macOS / Linux / WSL / Git Bash:**
```bash
cp .env.example .env
./run.sh
```
`run.sh` installs/updates dependencies (including the latest yt-dlp) automatically on every run — no manual `pip install` needed. Set `SKIP_DEP_INSTALL=1` to skip that and start faster once you know deps are current.

**Windows (native, no WSL required):**
```bat
copy .env.example .env
run.bat
```
Same behavior as `run.sh` — installs deps + upgrades yt-dlp automatically, then starts the server.

Open http://localhost:8000

Jobs run via FastAPI BackgroundTasks when Redis is not available.

## Production-style (Redis + Celery workers)

**1. Start Redis + Postgres (optional but recommended):**

```bash
# from repo root
docker compose up -d redis postgres
```

**2. API**

```bash
# from repo root
export DATABASE_URL=postgresql://shorts:shorts@localhost:5432/shorts
export CELERY_BROKER_URL=redis://localhost:6379/0
export CELERY_RESULT_BACKEND=redis://localhost:6379/1
./run.sh
```

**3. Worker (separate terminal)**

```bash
# from repo root
export CELERY_BROKER_URL=redis://localhost:6379/0
export CELERY_RESULT_BACKEND=redis://localhost:6379/1
./run-worker.sh  # Windows: run-worker.bat
# or: CELERY_CONCURRENCY=4 ./run-worker.sh
```

**Full stack Docker:**

```bash
docker compose up --build
```

## Payments

- Stripe: set `STRIPE_SECRET_KEY` + webhook secret
- Crypto: set `NOWPAYMENTS_API_KEY` (+ optional IPN secret)
- Without keys, both providers **simulate** and grant credits/plans

## Health

`GET /api/health` → `redis_available`, `queue_backend` (`celery` | `background`)

## YouTube downloads ("Sign in to confirm you're not a bot")

Set in `.env`:
```
YOUTUBE_COOKIES_FILE=/absolute/path/to/cookies.txt   # Windows: C:\path\to\cookies.txt is fine
```
Export cookies.txt with a browser extension (e.g. "Get cookies.txt LOCALLY") **while logged in to YouTube**, in Netscape format. If it still fails after that:

1. **Update yt-dlp.** `run.sh`/`run.bat` now do this automatically on every start. If you're not using them, run `pip install -U yt-dlp` yourself — YouTube changes bot-detection often and old yt-dlp builds fail even with perfect cookies.
2. **Re-export fresh cookies right before testing.** YouTube session cookies can go stale within hours to a few days.
3. **Cloud/VPS/Codespaces IPs get flagged far more than home IPs**, sometimes regardless of cookie validity. If it fails only in a cloud dev environment but works from your own PC, that's IP reputation, not a config problem — set `YOUTUBE_PROXY` to a residential proxy if you need it to work from the cloud environment specifically.
4. If it fails **even from your own residential connection** with freshly-exported cookies and the latest yt-dlp, check the exact error text returned in the job (`error` field / shown in the UI) rather than assuming it's the same cause each time — yt-dlp reuses similar wording for several distinct failure modes.

## Tests

```bash
# from repo root
PYTHONPATH=. pytest tests/ -q
```

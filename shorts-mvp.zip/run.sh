#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONPATH=.
mkdir -p uploads outputs backgrounds temp data assets
if [[ ! -f .env && -f .env.example ]]; then
  cp .env.example .env
  echo "Created .env from .env.example – edit secrets before production."
fi

# Install deps on first run (or after requirements.txt changes), then always
# pull the newest yt-dlp — YouTube changes its bot-check constantly and an
# outdated yt-dlp is one of the most common causes of "Sign in to confirm
# you're not a bot" even with valid cookies. Skip with SKIP_DEP_INSTALL=1.
if [[ "${SKIP_DEP_INSTALL:-0}" != "1" ]]; then
  PYBIN="python3"; command -v python3 >/dev/null 2>&1 || PYBIN="python"
  echo "Checking dependencies…"
  "$PYBIN" -m pip install -q -r requirements.txt
  echo "Upgrading yt-dlp to the latest version…"
  "$PYBIN" -m pip install -q -U yt-dlp
fi

exec uvicorn app.main:app --host 0.0.0.0 --port "${PORT:-8000}" --reload

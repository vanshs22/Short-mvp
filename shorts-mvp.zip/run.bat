@echo off
setlocal
cd /d "%~dp0"
set PYTHONPATH=.

if not exist uploads mkdir uploads
if not exist outputs mkdir outputs
if not exist backgrounds mkdir backgrounds
if not exist temp mkdir temp
if not exist data mkdir data
if not exist assets mkdir assets

if not exist .env (
  if exist .env.example (
    copy /Y .env.example .env >nul
    echo Created .env from .env.example - edit secrets before production.
  )
)

where python >nul 2>&1
if %errorlevel%==0 (
  set PYBIN=python
) else (
  set PYBIN=py
)

if "%SKIP_DEP_INSTALL%"=="1" (
  echo Skipping dependency install ^(SKIP_DEP_INSTALL=1^)
) else (
  echo Checking dependencies...
  %PYBIN% -m pip install -q -r requirements.txt
  if errorlevel 1 (
    echo pip install failed - see errors above.
    exit /b 1
  )
  echo Upgrading yt-dlp to the latest version...
  %PYBIN% -m pip install -q -U yt-dlp
)

if "%PORT%"=="" set PORT=8000
echo Starting server on http://localhost:%PORT%
%PYBIN% -m uvicorn app.main:app --host 0.0.0.0 --port %PORT% --reload
